package generator

import (
	"errors"
	"fmt"
)

// DAG represents a Directed Acyclic Graph of pipeline steps
type DAG struct {
	Nodes []*Node
	Edges map[int][]int
}

// Node represents a single execution step
type Node struct {
	ID          int
	Name        string
	Action      string
	RequiresState bool
	CheckpointAfter bool
	JoinKey     string // If present, indicates a join dependency
}

// NewDAG creates a DAG with a preallocated number of nodes
func NewDAG(size int) *DAG {
	return &DAG{
		Nodes: make([]*Node, 0, size),
		Edges: make(map[int][]int),
	}
}

// AddNode inserts a new Node into the DAG
func (d *DAG) AddNode(n *Node) int {
	n.ID = len(d.Nodes)
	d.Nodes = append(d.Nodes, n)
	return n.ID
}

// AddEdge connects parent node to child node
func (d *DAG) AddEdge(parentID, childID int) {
	d.Edges[parentID] = append(d.Edges[parentID], childID)
}

// Validate checks basic DAG consistency
func (d *DAG) Validate() error {
	if len(d.Nodes) == 0 {
		return errors.New("DAG has no nodes")
	}

	if err := d.checkStartNodes(); err != nil {
		return err
	}

	if err := d.checkTerminalNodes(); err != nil {
		return err
	}

	if err := d.detectCycles(); err != nil {
		return err
	}

	return nil
}

// checkStartNodes ensures at least one root node exists (no inputs)
func (d *DAG) checkStartNodes() error {
	for _, node := range d.Nodes {
		if len(node.Inputs) == 0 {
			return nil // Found at least one source node
		}
	}
	return errors.New("no starting node detected in DAG")
}

// checkTerminalNodes ensures at least one sink node exists (no outputs)
func (d *DAG) checkTerminalNodes() error {
	for _, node := range d.Nodes {
		if len(node.Outputs) == 0 {
			return nil // Found at least one terminal node
		}
	}
	return errors.New("no terminal node detected in DAG")
}

// detectCycles checks for DAG cycles (very basic DFS)
func (d *DAG) detectCycles() error {
	visited := make(map[string]bool)
	recStack := make(map[string]bool)

	for _, node := range d.Nodes {
		if !visited[node.Name] {
			if d.dfsCycle(node, visited, recStack) {
				return fmt.Errorf("cycle detected at node: %s", node.Name)
			}
		}
	}

	return nil
}

// dfsCycle performs depth-first cycle detection
func (d *DAG) dfsCycle(node *Node, visited, recStack map[string]bool) bool {
	visited[node.Name] = true
	recStack[node.Name] = true

	for _, child := range node.Outputs {
		if !visited[child.Name] && d.dfsCycle(child, visited, recStack) {
			return true
		}
		if recStack[child.Name] {
			return true
		}
	}

	recStack[node.Name] = false
	return false
}

// ValidateStepMetadata ensures required annotations are present and valid.
func ValidateStepMetadata(step *Step) error {
	if step.Name == "" {
		return fmt.Errorf("missing @step annotation")
	}
	if step.Input == "" {
		return fmt.Errorf("missing @step_input for step: %s", step.Name)
	}
	if step.Output == "" {
		return fmt.Errorf("missing @step_output for step: %s", step.Name)
	}
	return nil
}

