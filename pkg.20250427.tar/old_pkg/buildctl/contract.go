package contract

import (
	"go/ast"
	"strings"
)

// ExtractAnnotatedSteps parses a Go contract file and returns extracted Steps.
func ExtractAnnotatedSteps(path string) ([]Step, error) {
	nodes, err := ParseGoFile(path)
	if err != nil {
		return nil, err
	}

	steps := make([]Step, 0, len(nodes)) // DOD: preallocate
	for _, node := range nodes {
		step, err := ParseStructAnnotations(node)
		if err != nil {
			return nil, err
		}
		if err := ValidateStepMetadata(&step); err != nil {
			return nil, err
		}
		steps = append(steps, step)
	}
	return steps, nil
}

// ExtractContractMetadata parses @feature, @scenario, etc at file-level
func ExtractContractMetadata(path string) (*Metadata, error) {
	nodes, err := ParseGoFile(path)
	if err != nil {
		return nil, err
	}

	meta := &Metadata{}
	for _, node := range nodes {
		if node.Doc != nil {
			for _, comment := range node.Doc.List {
				text := trimComment(comment.Text)
				if strings.HasPrefix(text, "@feature:") {
					meta.Feature = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@scenario:") {
					meta.Scenario = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@herd:") {
					meta.Herd = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@contract:") {
					meta.Contract = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@version:") {
					meta.Version = parseTagValue(text)
				}
			}
		}
	}
	return meta, nil
}
