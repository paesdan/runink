package render

import (
	"fmt"
	"io"
	"regexp"
	"strconv"
	"github.com/runink/pkg/dsl"
)

// EmitSLATracing injects SLA observability annotations
func EmitSLATracing(w io.Writer, metadata dsl.Metadata) error {
	_, err := fmt.Fprintf(w, "\n// SLA: %s, Classification: %s\n", metadata.SLO, metadata.Classification)
	return err
}

// EmitTLSHeaders writes security metadata
func EmitTLSHeaders(w io.Writer, metadata dsl.Metadata) error {
	if metadata.TLSRequired {
		_, err := fmt.Fprintf(w, "// ⚡ TLS is enforced for this DAG slice\n")
		return err
	}
	return nil
}

func StreamDAGWithCompliance(dag *generator.DAG, w io.Writer, metadata dsl.Metadata) error {
	if err := EmitComplianceAndSLAMetrics(metadata, w); err != nil {
		return err
	}
	if err := EmitTLSHeaders(w, metadata); err != nil {
		return err
	}
	if metadata.TLSRequired {
		if err := EmitCertificateFingerprint(w, metadata.TLSFingerprint); err != nil {
			return err
		}
	}
	return renderDAGSteps(dag, w)
}


// EmitCertificateFingerprint emits TLS fingerprint if TLS is required
func EmitCertificateFingerprint(w io.Writer, certFingerprint string) error {
	_, err := fmt.Fprintf(w, `
	// TLS Certificate Fingerprint: %s
	`, certFingerprint)
	return err
}


// EmitComplianceAndSLAMetrics writes Prometheus SLA gauge metrics
func EmitComplianceAndSLAMetrics(metadata dsl.Metadata, w io.Writer) error {
	slaSeconds := parseSLASeconds(metadata.SLO)

	_, err := fmt.Fprintf(w, `
	// --- Runink Compliance & SLA Metrics ---
	// TLS Required: %t
	// SLA Target (P99): %.1f seconds

	// Prometheus SLA Export
	runi_pipeline_sla_target_seconds{
		herd="%s",
		feature="%s",
		scenario="%s"
	} %.1f
	`, 
		metadata.TLSRequired,
		slaSeconds,
		metadata.Herd,
		metadata.Feature,
		metadata.Scenario,
		slaSeconds,
	)
	return err
}

// EmitTLSHeaders injects TLS compliance enforcement markers
func EmitTLSHeaders(w io.Writer, metadata dsl.Metadata) error {
	if metadata.TLSRequired {
		_, err := fmt.Fprintln(w, "// ⚡ TLS ENFORCED: All slice traffic secured with mTLS")
		return err
	}
	return nil
}

// parseSLASeconds extracts SLA window in seconds from SLO strings like "30s", "60s"
func parseSLASeconds(slo string) float64 {
	re := regexp.MustCompile(`(\d+)s`)
	matches := re.FindStringSubmatch(slo)
	if len(matches) < 2 {
		return 60.0 // fallback default
	}
	sec, _ := strconv.ParseFloat(matches[1], 64)
	return sec
}

// renderDAGSteps streams the DAG structure
func renderDAGSteps(dag *generator.DAG, w io.Writer) error {
	for _, step := range dag.Steps {
		_, err := fmt.Fprintf(w, "// Step: %s\n", step.Name)
		if err != nil {
			return err
		}
	}
	return nil
}
