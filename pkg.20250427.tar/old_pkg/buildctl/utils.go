package generator

import (
	"sort"
	"strings"
)

// sanitizeNodeName makes node names safe for Go variable usage
func sanitizeNodeName(name string) string {
	name = strings.ToLower(name)
	name = strings.ReplaceAll(name, " ", "_")
	name = strings.ReplaceAll(name, "-", "_")
	name = strings.ReplaceAll(name, ".", "_")
	return name
}

// sortNodesByStage sorts nodes by their assigned stage number
func sortNodesByStage(nodes []*Node) {
	sort.Slice(nodes, func(i, j int) bool {
		return nodes[i].Stage < nodes[j].Stage
	})
}

// uniqueNodeName ensures uniqueness if needed (future use)
func uniqueNodeName(base string, suffix int) string {
	return sanitizeNodeName(base) + "_" + fmt.Sprintf("%d", suffix)
}

// safeAppend appends a child to a slice if not already present
func safeAppend(slice []*Node, node *Node) []*Node {
	for _, n := range slice {
		if n == node {
			return slice
		}
	}
	return append(slice, node)
}

// parseTagValue extracts right-hand side after colon.
func parseTagValue(text string) string {
	parts := strings.SplitN(text, ":", 2)
	if len(parts) < 2 {
		return ""
	}
	return strings.TrimSpace(parts[1])
}

// parseBoolValue parses true/false tag.
func parseBoolValue(text string) bool {
	v := parseTagValue(text)
	return strings.EqualFold(v, "true")
}


// CleanString trims whitespace and lowercases a string
func CleanString(s string) string {
	return strings.TrimSpace(strings.ToLower(s))
}

