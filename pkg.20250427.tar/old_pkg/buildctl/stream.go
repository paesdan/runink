package render

import (
	"io"
	"github.com/runink/pkg/dsl"
)

// StreamDAGWithCompliance renders the DAG while injecting SLA, lineage, security
func StreamDAGWithCompliance(dag *generator.DAG, w io.Writer, metadata dsl.Metadata) error {
	if err := EmitHeaders(w, metadata); err != nil {
		return err
	}
	if err := EmitDAGSteps(w, dag); err != nil {
		return err
	}
	if err := EmitSLATracing(w, metadata); err != nil {
		return err
	}
	return nil
}
