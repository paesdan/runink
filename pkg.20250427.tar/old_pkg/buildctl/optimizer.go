package generator

// Options control DAG optimization behaviors
type Options struct {
	EnableStreaming        bool
	UseStructReuse         bool
	ApplyAffinityTags      bool
	ApplyCheckpointing     bool
	ApplyCgroupEnforcement bool
}

// Optimize applies optimizations to a DAG
func (d *DAG) Optimize(opts Options) {
	for _, node := range d.Nodes {
		// Enable streaming pipelines
		if opts.EnableStreaming {
			node.StreamingEnabled = true
		}

		// Apply struct reuse hints
		if opts.UseStructReuse {
			node.StructReuseHint = true
		}

		// Apply checkpointing after critical steps
		if opts.ApplyCheckpointing && node.CheckpointAfter {
			node.EnableCheckpoint = true
		}

		// Apply affinity/cgroup hints
		if opts.ApplyAffinityTags {
			node.AffinityTag = deriveAffinityTag(node)
		}
		if opts.ApplyCgroupEnforcement {
			node.CgroupEnforced = true
		}
	}
}

// deriveAffinityTag derives a simple affinity label from node name
func deriveAffinityTag(n *Node) string {
	// Very simple heuristic for now — can get smarter later
	if n.RequiresState {
		return "stateful"
	}
	return "stateless"
}
