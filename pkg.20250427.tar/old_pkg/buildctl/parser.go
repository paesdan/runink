package contract

import (
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"strings"
)

// ParseGoFile loads and parses a Go source file into AST type specs.
func ParseGoFile(path string) ([]*ast.TypeSpec, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "", src, parser.ParseComments)
	if err != nil {
		return nil, err
	}

	var specs []*ast.TypeSpec
	for _, decl := range node.Decls {
		if genDecl, ok := decl.(*ast.GenDecl); ok {
			for _, spec := range genDecl.Specs {
				if typeSpec, ok := spec.(*ast.TypeSpec); ok {
					specs = append(specs, typeSpec)
				}
			}
		}
	}
	return specs, nil
}

// ParseStructAnnotations extracts step metadata from struct comments.
func ParseStructAnnotations(spec *ast.TypeSpec) (Step, error) {
	step := Step{
		Annotations: make(map[string]string),
	}
	if spec.Doc != nil {
		for _, comment := range spec.Doc.List {
			text := strings.TrimSpace(strings.TrimPrefix(comment.Text, "//"))
			if strings.HasPrefix(text, "@step:") {
				step.Name = parseTagValue(text)
			} else if strings.HasPrefix(text, "@step_input:") {
				step.Input = parseTagValue(text)
			} else if strings.HasPrefix(text, "@step_output:") {
				step.Output = parseTagValue(text)
			} else if strings.HasPrefix(text, "@join_key:") {
				step.JoinKey = parseTagValue(text)
			} else if strings.HasPrefix(text, "@requires_state:") {
				step.RequiresState = parseBoolValue(text)
			} else if strings.HasPrefix(text, "@checkpoint_after:") {
				step.CheckpointAfter = parseBoolValue(text)
			} else if strings.HasPrefix(text, "@affinity:") {
				step.AffinityTags = append(step.AffinityTags, parseTagValue(text))
			} else if strings.HasPrefix(text, "@sink:") {
				step.SinkTargets = append(step.SinkTargets, parseTagValue(text))
			} else if strings.Contains(text, ":") {
				parts := strings.SplitN(text, ":", 2)
				k := strings.TrimSpace(parts[0])
				v := strings.TrimSpace(parts[1])
				step.Annotations[k] = v
			}
		}
	}
	return step, nil
}
