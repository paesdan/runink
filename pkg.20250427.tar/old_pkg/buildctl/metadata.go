package generator

import (
	"github.com/runink/pkg/envloader"
	"github.com/runink/pkg/herdloader"
)

// GeneratorMetadata holds full metadata for DAG generation and optimization
type GeneratorMetadata struct {
	HerdConfig       herdloader.HerdConfig   // Full Herd quotas, security, governance
	FeatureMetadata  envloader.Metadata      // Full Feature metadata including SLA, lineage
	ContractChecksum string                  // Contract file checksum
	GeneratedAt      int64                   // Timestamp when DAG was generated
	Version          string                  // Generator version (future-proofing)
}

// ContractMetadata defines full contract + feature metadata for Runink contracts
type ContractMetadata struct {
	FeatureMetadata envloader.Metadata 				// 🛡 Full feature and contract metadata
	Compliance      envloader.OperationalCompliance // 📜 Compliance fields (operational, security, access)
	SchemaPath      string              			// 📄 Path to .go or schema file
	Checksum        string              			// 🔐 Checksum for golden data validation
	Version         string              			// 📦 Contract version (ex: 1.0.0)
	ContractHash    string              			// 🔑 Contract source code hash
	LineageID       string              			// 🧬 Lineage traceability ID
	AccessPolicy    string              			// 🔐 Access policy, eg: herd-isolated	
	Timestamp       int64               			// ⏱ Registration timestamp (epoch)
}

// Step represents an extracted pipeline step from a contract
type Step struct {
	Name             string            // @step
	Input            string            // @step_input
	Output           string            // @step_output
	JoinKey          string            // @join_key (optional)
	RequiresState    bool              // @requires_state (true/false)
	CheckpointAfter  bool              // @checkpoint_after (true/false)
	AffinityTags     []string          // @affinity labels
	SinkTargets      []string          // @sink output
	Annotations      map[string]string // Raw @key:value annotations
}


// DslMetadata defines full DSL + feature metadata for Runink DSL
type DslMetadata struct {
	FeatureMetadata envloader.Metadata 				// 🛡 Full feature and contract metadata
	Compliance      envloader.OperationalCompliance // 📜 Compliance fields (operational, security, access)
	SchemaPath      string              			// 📄 Path to .go or schema file
	Checksum        string              			// 🔐 Checksum for golden data validation
	Version         string              			// 📦 Contract version (ex: 1.0.0)
	ContractHash    string              			// 🔑 Contract source code hash
	LineageID       string              			// 🧬 Lineage traceability ID
	AccessPolicy    string              			// 🔐 Access policy, eg: herd-isolated	
	Timestamp       int64               			// ⏱ Registration timestamp (epoch)
}
