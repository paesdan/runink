package generator

import (
	"errors"
	"fmt"
)

// Validate checks basic DAG consistency
func (d *DAG) Validate() error {
	if len(d.Nodes) == 0 {
		return errors.New("DAG has no nodes")
	}

	if err := d.checkStartNodes(); err != nil {
		return err
	}

	if err := d.checkTerminalNodes(); err != nil {
		return err
	}

	if err := d.detectCycles(); err != nil {
		return err
	}

	return nil
}

// checkStartNodes ensures at least one root node exists (no inputs)
func (d *DAG) checkStartNodes() error {
	for _, node := range d.Nodes {
		if len(node.Inputs) == 0 {
			return nil // Found at least one source node
		}
	}
	return errors.New("no starting node detected in DAG")
}

// checkTerminalNodes ensures at least one sink node exists (no outputs)
func (d *DAG) checkTerminalNodes() error {
	for _, node := range d.Nodes {
		if len(node.Outputs) == 0 {
			return nil // Found at least one terminal node
		}
	}
	return errors.New("no terminal node detected in DAG")
}

// detectCycles checks for DAG cycles (very basic DFS)
func (d *DAG) detectCycles() error {
	visited := make(map[string]bool)
	recStack := make(map[string]bool)

	for _, node := range d.Nodes {
		if !visited[node.Name] {
			if d.dfsCycle(node, visited, recStack) {
				return fmt.Errorf("cycle detected at node: %s", node.Name)
			}
		}
	}

	return nil
}

// dfsCycle performs depth-first cycle detection
func (d *DAG) dfsCycle(node *Node, visited, recStack map[string]bool) bool {
	visited[node.Name] = true
	recStack[node.Name] = true

	for _, child := range node.Outputs {
		if !visited[child.Name] && d.dfsCycle(child, visited, recStack) {
			return true
		}
		if recStack[child.Name] {
			return true
		}
	}

	recStack[node.Name] = false
	return false
}

package contract

import "fmt"

// ValidateStepMetadata ensures required annotations are present and valid.
func ValidateStepMetadata(step *Step) error {
	if step.Name == "" {
		return fmt.Errorf("missing @step annotation")
	}
	if step.Input == "" {
		return fmt.Errorf("missing @step_input for step: %s", step.Name)
	}
	if step.Output == "" {
		return fmt.Errorf("missing @step_output for step: %s", step.Name)
	}
	return nil
}
