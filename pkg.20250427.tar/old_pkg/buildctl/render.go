package render

import (
	"io"
	"github.com/runink/pkg/dsl"
	"github.com/runink/pkg/generator"
)

// ToGoFile renders the final DAG into a Go file
func ToGoFile(dag *generator.DAG, w io.Writer, metadata dsl.Metadata) error {
	if err := EmitHeaders(w, metadata); err != nil {
		return err
	}
	if err := EmitDAGSteps(w, dag); err != nil {
		return err
	}
	return nil
}
