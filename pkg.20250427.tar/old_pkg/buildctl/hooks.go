package render

import (
	"fmt"
	"io"
)

// EmitSLAAlertTemplate emits a Prometheus alert for SLA breach
func EmitSLAAlertTemplate(w io.Writer, herd, feature, scenario string, thresholdSeconds float64) error {
	_, err := fmt.Fprintf(w, `
alert: RuninkPipelineSLABreach
expr: runi_pipeline_sla_target_seconds{herd="%s",feature="%s",scenario="%s"} > %.1f
for: 5m
labels:
  severity: critical
annotations:
  summary: "Runink SLA breach detected for %s/%s"
  description: "Pipeline %s/%s exceeded SLA target of %.1f seconds."
`, herd, feature, scenario, thresholdSeconds, herd, feature, herd, feature, thresholdSeconds)
	return err
}
