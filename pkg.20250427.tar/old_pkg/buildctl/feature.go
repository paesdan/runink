package dsl

// Scenario defines a parsed Feature DSL
type Scenario struct {
	Metadata Metadata    `yaml:"metadata,omitempty"`
	Steps    []Step       `yaml:"steps"`
	When     []string     `yaml:"when,omitempty"`
	Then     []StepAction `yaml:"then"`
	Do       []DoAction   `yaml:"do"`
}

// StepAction describes a "then" block in DSL
type StepAction struct {
	Action         string `yaml:"action"`
	Step           string `yaml:"step"`
	RequiresState  bool   `yaml:"requires_state"`
	JoinKey        string `yaml:"join_key,omitempty"`
	CheckpointAfter bool  `yaml:"checkpoint_after,omitempty"`
}

// DoAction describes a "do" block (sinks, outputs)
type DoAction struct {
	Sink      string `yaml:"sink"`
	Condition string `yaml:"condition,omitempty"`
}
