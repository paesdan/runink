package generator

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/runink/pkg/contract"
	"github.com/runink/pkg/dsl"
	"github.com/runink/pkg/envloader"
	"github.com/runink/pkg/generator"
	"github.com/runink/pkg/herdloader"
	"github.com/runink/pkg/hashing"
	"github.com/runink/pkg/raftctl"
	"github.com/runink/pkg/render"
	"github.com/runink/pkg/secrets"
	"github.com/spf13/cobra"
)

var (
	featurePath  string
	contractPath string
	envPath      string
	herdPath     string
	outputDir    string
	secretsPath  string
	masterKeyEnv string
)

// CLI: runi generate
var generateCmd = &cobra.Command{
	Use:   "generate",
	Short: "Generate a Runink DAG from feature.dsl and contract.go",
	Run: func(cmd *cobra.Command, args []string) {
		runGenerate()
	},
}

func init() {
	generateCmd.Flags().StringVar(&featurePath, "feature", "", "Path to feature.dsl file (required)")
	generateCmd.Flags().StringVar(&contractPath, "contract", "", "Path to contract.go file (required)")
	generateCmd.Flags().StringVar(&envPath, "env", "", "Path to environment .env file (required)")
	generateCmd.Flags().StringVar(&herdPath, "herd", "", "Path to herd.yml definition file (required)")
	generateCmd.Flags().StringVar(&outputDir, "out", "rendered", "Directory to output generated Go files")
	generateCmd.Flags().StringVar(&secretsPath, "secrets", "secretsdb", "Path for secrets BadgerDB storage")
	generateCmd.Flags().StringVar(&masterKeyEnv, "masterkey", "RUNINK_MASTER_KEY", "Env var holding master encryption key")
	generateCmd.MarkFlagRequired("feature")
	generateCmd.MarkFlagRequired("contract")
	generateCmd.MarkFlagRequired("env")
	generateCmd.MarkFlagRequired("herd")
}
// BuildDAGInto builds a DAG from a Scenario and prepared Steps
func BuildDAGInto(dag *DAG, scenario *dsl.Scenario, steps []Step) error {
	stepIDs := make(map[string]int)

	// 1. Create all Nodes first
	for _, step := range steps {
		node := &Node{
			Name:            step.Name,
			Action:          step.Action,
			RequiresState:   step.RequiresState,
			CheckpointAfter: step.CheckpointAfter,
			JoinKey:         step.JoinKey,
		}
		id := dag.AddNode(node)
		stepIDs[step.Name] = id
	}

	// 2. Wire Edges based on JoinKey or Sequential
	for idx, step := range steps {
		currentID := stepIDs[step.Name]

		// If a JoinKey is specified, wire it
		if step.JoinKey != "" {
			parentID, exists := stepIDs[step.JoinKey]
			if !exists {
				return fmt.Errorf("join key step %s not found for step %s", step.JoinKey, step.Name)
			}
			dag.AddEdge(parentID, currentID)
		} else if idx > 0 {
			// Sequential fallback
			prevID := stepIDs[steps[idx-1].Name]
			dag.AddEdge(prevID, currentID)
		}
	}

	return nil
}

func runGenerate() {
	// 1. Load Environment
	if err := envloader.LoadFromFile(envPath); err != nil {
		log.Fatalf("❌ Failed to load env file: %v", err)
	}

	// 2. Validate Metadata + Compliance from env
	if err := envloader.ValidateMetadataEnv(); err != nil {
		log.Fatalf("❌ Metadata env vars missing: %v", err)
	}
	if err := envloader.ValidateComplianceEnv(); err != nil {
		log.Fatalf("❌ Compliance env vars missing: %v", err)
	}

	// 3. Initialize Secrets Manager
	if err := bootstrapSecretsManager(); err != nil {
		log.Fatalf("❌ Failed to initialize Secrets Manager: %v", err)
	}

	// 4. Parse Feature DSL
	scenario, err := dsl.ParseFile(featurePath)
	if err != nil {
		log.Fatalf("❌ Failed to parse DSL: %v", err)
	}
	log.Printf("✅ Feature loaded: %s / Scenario: %s", scenario.Metadata.Feature, scenario.Metadata.Scenario)

	// 5. Parse Herd Config
	herdConfig, err := herdloader.ParseFile(herdPath)
	if err != nil {
		log.Fatalf("❌ Failed to parse herd config: %v", err)
	}
	log.Printf("✅ Herd loaded: %s (Quotas: %+v)", herdConfig.Name, herdConfig.Quotas)

	// 6. Parse Contract Steps
	steps, err := contract.ExtractAnnotatedSteps(contractPath)
	if err != nil {
		log.Fatalf("❌ Failed to extract contract steps: %v", err)
	}

	// 7. Parse Contract Metadata
	contractMeta, err := contract.ExtractContractMetadata(contractPath)
	if err != nil {
		log.Fatalf("❌ Failed to extract contract metadata: %v", err)
	}

	// 8. Compute Contract Hash
	contractHash, err := hashing.ComputeFileHash(contractPath)
	if err != nil {
		log.Fatalf("❌ Failed to compute contract hash: %v", err)
	}
	contractMeta.ContractHash = contractHash
	log.Printf("📜 Contract Hash: %s", contractHash)

	// 9. Populate Scenario Metadata
	scenario.Metadata.Feature = contractMeta.Feature
	scenario.Metadata.Scenario = contractMeta.Scenario
	scenario.Metadata.Herd = contractMeta.Herd
	scenario.Metadata.Contract = contractMeta.Contract
	scenario.Metadata.Version = contractMeta.Version
	scenario.Metadata.ContractHash = contractMeta.ContractHash

	scenario.Metadata.QualityTier = herdConfig.Governance.QualityTier
	scenario.Metadata.SLO = herdConfig.Governance.SLO
	scenario.Metadata.Classification = herdConfig.Governance.Classification
	scenario.Metadata.GovernancePolicy = herdConfig.Governance.GovernancePolicy
	scenario.Metadata.AccessPolicy = herdConfig.Governance.AccessPolicy
	scenario.Metadata.TLSRequired = herdConfig.Security.TLSRequired
	scenario.Metadata.LineageID = hashing.GenerateLineageID(scenario.Metadata)

	scenario.Metadata.Compliance = dsl.OperationalCompliance{
		OperationalStatus:   herdConfig.Compliance.OperationalStatus,
		RecoveryStatus:      herdConfig.Compliance.RecoveryStatus,
		DataSecurityStatus:  herdConfig.Compliance.DataSecurityStatus,
		AccessControlStatus: herdConfig.Compliance.AccessControlStatus,
	}

	// 10. Initialize Raft Client
	raftClient := raftctl.NewClient()

	// 11. Register Feature Metadata into Raft
	if err := raftClient.RegisterFeatureFullMetadata(scenario.Metadata, herdConfig); err != nil {
		log.Fatalf("❌ Failed to register DAG metadata: %v", err)
	}

	// 12. Pre-build DAG
	preparedSteps := generator.PrepareStepsFromScenario(scenario)
	dag := generator.NewDAG(len(preparedSteps) + 2)
	if err := generator.BuildDAGInto(dag, scenario, preparedSteps); err != nil {
		log.Fatalf("❌ DAG build failed: %v", err)
	}

	// 13. Optimize DAG
	dag.Optimize(generator.Options{
		EnableStreaming:        true,
		UseStructReuse:         true,
		ApplyAffinityTags:      true,
		ApplyCheckpointing:     true,
		ApplyCgroupEnforcement: true,
	})

	// 14. Render DAG to Output
	if err := os.MkdirAll(outputDir, 0755); err != nil {
		log.Fatalf("❌ Failed to create output dir: %v", err)
	}

	outPath := filepath.Join(outputDir, sanitize(scenario.Metadata.Feature)+".go")
	outFile, err := os.Create(outPath)
	if err != nil {
		log.Fatalf("❌ Failed to create DAG output file: %v", err)
	}
	defer outFile.Close()

	reader, writer := io.Pipe()
	var wg sync.WaitGroup
	wg.Add(1)

	go func() {
		defer wg.Done()
		if _, err := io.Copy(outFile, reader); err != nil {
			log.Fatalf("❌ Failed to copy DAG output: %v", err)
		}
	}()

	if err := render.StreamDAGWithCompliance(dag, writer, scenario.Metadata); err != nil {
		log.Fatalf("❌ Failed to render DAG: %v", err)
	}
	writer.Close()
	wg.Wait()

	log.Printf("✅ DAG generated at: %s", outPath)

	// 15. Register Generator Metadata
	genMeta := generator.GeneratorMetadata{
		HerdConfig:       herdConfig,
		FeatureMetadata:  scenario.Metadata,
		ContractChecksum: contractHash,
		GeneratedAt:      time.Now().Unix(),
		Version:          "v1.0.0", // TODO: automate via build flags
	}

	if err := raftClient.RegisterGeneratorMetadata(genMeta); err != nil {
		log.Fatalf("❌ Failed to register generator metadata: %v", err)
	}

	log.Printf("✅ Generator metadata registered into Raft/Badger.")
}

// sanitize safely lowers and replaces spaces for filenames
func sanitize(name string) string {
	return strings.ReplaceAll(strings.ToLower(name), " ", "_")
}

// bootstrapSecretsManager initializes the secrets store
func bootstrapSecretsManager() error {
	masterKey := os.Getenv(masterKeyEnv)
	if len(masterKey) == 0 {
		return fmt.Errorf("master encryption key (%s) missing", masterKeyEnv)
	}
	secrets.LoadMasterKey([]byte(masterKey))
	if err := secrets.InitStore(secretsPath); err != nil {
		return fmt.Errorf("secrets store initialization failed: %v", err)
	}
	log.Printf("🔐 Secrets Manager initialized at: %s", secretsPath)
	return nil
}

// PrepareStepsFromScenario maps parsed Scenario into executable StepList
func PrepareStepsFromScenario(s *dsl.Scenario) []Step {
	steps := make([]Step, 0, len(s.Then))

	for _, action := range s.Then {
		step := Step{
			Name:            action.Step,
			RequiresState:   action.RequiresState,
			CheckpointAfter: action.CheckpointAfter,
			JoinKey:         action.JoinKey,
			Action:          action.Action,
		}
		steps = append(steps, step)
	}

	return steps
}

// ToGoFile renders the final DAG into a Go file
func ToGoFile(dag *generator.DAG, w io.Writer, metadata dsl.Metadata) error {
	if err := EmitHeaders(w, metadata); err != nil {
		return err
	}
	if err := EmitDAGSteps(w, dag); err != nil {
		return err
	}
	return nil
}

package contract

import (
	"go/ast"
	"strings"
)

// ExtractAnnotatedSteps parses a Go contract file and returns extracted Steps.
func ExtractAnnotatedSteps(path string) ([]Step, error) {
	nodes, err := ParseGoFile(path)
	if err != nil {
		return nil, err
	}

	steps := make([]Step, 0, len(nodes)) // DOD: preallocate
	for _, node := range nodes {
		step, err := ParseStructAnnotations(node)
		if err != nil {
			return nil, err
		}
		if err := ValidateStepMetadata(&step); err != nil {
			return nil, err
		}
		steps = append(steps, step)
	}
	return steps, nil
}

// ExtractContractMetadata parses @feature, @scenario, etc at file-level
func ExtractContractMetadata(path string) (*Metadata, error) {
	nodes, err := ParseGoFile(path)
	if err != nil {
		return nil, err
	}

	meta := &Metadata{}
	for _, node := range nodes {
		if node.Doc != nil {
			for _, comment := range node.Doc.List {
				text := trimComment(comment.Text)
				if strings.HasPrefix(text, "@feature:") {
					meta.Feature = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@scenario:") {
					meta.Scenario = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@herd:") {
					meta.Herd = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@contract:") {
					meta.Contract = parseTagValue(text)
				}
				if strings.HasPrefix(text, "@version:") {
					meta.Version = parseTagValue(text)
				}
			}
		}
	}
	return meta, nil
}
