package contract

// Step represents an extracted pipeline step from a contract
type Step struct {
	Name             string            // @step
	Input            string            // @step_input
	Output           string            // @step_output
	JoinKey          string            // @join_key (optional)
	RequiresState    bool              // @requires_state (true/false)
	CheckpointAfter  bool              // @checkpoint_after (true/false)
	AffinityTags     []string          // @affinity labels
	SinkTargets      []string          // @sink output
	Annotations      map[string]string // Raw @key:value annotations
}

package contract

type Step struct {
	Name             string
	Input            string
	Output           string
	JoinKey          string
	RequiresState    bool
	CheckpointAfter  bool
	AffinityTags     []string
	SinkTargets      []string
	Annotations      map[string]string
}
