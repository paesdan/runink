package dsl

import "fmt"

// ValidateScenario ensures Scenario has valid structure
func ValidateScenario(s *Scenario) error {
	if s.Metadata.Feature == "" {
		return fmt.Errorf("feature is required")
	}
	if s.Metadata.Scenario == "" {
		return fmt.Errorf("scenario is required")
	}
	if len(s.Then) == 0 {
		return fmt.Errorf("then block must have at least one step")
	}
	if len(s.Do) == 0 {
		return fmt.Errorf("do block must have at least one sink/output")
	}
	return nil
}
