package render

import (
	"fmt"
	"io"
)

// EmitGraphviz exports DAG into Graphviz .dot format
func EmitGraphviz(dag *generator.DAG, w io.Writer) error {
	_, err := fmt.Fprintln(w, "digraph DAG {")
	if err != nil {
		return err
	}

	for _, step := range dag.Steps {
		for _, next := range step.Dependencies {
			_, err := fmt.Fprintf(w, `  "%s" -> "%s";`+"\n", step.Name, next.Name)
			if err != nil {
				return err
			}
		}
	}

	_, err = fmt.Fprintln(w, "}")
	return err
}
