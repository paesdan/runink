package dsl

import (
	"io/ioutil"
	"gopkg.in/yaml.v3"
)

// ParseFile parses a feature DSL YAML file into a Scenario struct
func ParseFile(path string) (*Scenario, error) {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}

	scenario := &Scenario{}
	if err := yaml.Unmarshal(data, scenario); err != nil {
		return nil, err
	}

	if err := ValidateScenario(scenario); err != nil {
		return nil, err
	}

	return scenario, nil
}

// Steps defines the full list of what happens inside a scenario
type Steps struct {
	Ingest SourceStep    `yaml:"ingest"`
	When   []string      `yaml:"when"`
	Then   []Transform   `yaml:"then"`
	Do     []SinkAction  `yaml:"do"`
}

// SourceStep defines the data source
type SourceStep struct {
	Name  string `yaml:"name"`
	Topic string `yaml:"topic"`
}

// Transform defines a processing step
type Transform struct {
	Action         string `yaml:"action"`
	Step           string `yaml:"step"`
	RequiresState  bool   `yaml:"requires_state"`
	CheckpointAfter bool  `yaml:"checkpoint_after,omitempty"`
	JoinKey        string `yaml:"join_key,omitempty"`
}

// SinkAction defines where final results go
type SinkAction struct {
	Sink      string `yaml:"sink"`
	Condition string `yaml:"condition,omitempty"`
	CheckpointAfter bool `yaml:"checkpoint_after,omitempty"`
}
