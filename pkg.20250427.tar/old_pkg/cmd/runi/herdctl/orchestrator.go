package herdctl

import (
    "github.com/spf13/cobra"
    "fmt"
)

func NewCreateCommand() *cobra.Command {
    var quotaCPU int
    var quotaMemory string
    var herdName string

    cmd := &cobra.Command{
        Use:   "create",
        Short: "Create a new Herd",
        RunE: func(cmd *cobra.Command, args []string) error {
            return CreateHerd(herdName, quotaCPU, quotaMemory)
        },
    }

    cmd.Flags().StringVar(&herdName, "name", "", "Name of the Herd (required)")
    cmd.Flags().IntVar(&quotaCPU, "cpu", 2, "CPU quota")
    cmd.Flags().StringVar(&quotaMemory, "memory", "4Gi", "Memory quota")
    cmd.MarkFlagRequired("name")

    return cmd
}

func CreateHerd(name string, cpu int, memory string) error {
    fmt.Printf("Creating Herd '%s' with %d CPUs and %s memory...\n", name, cpu, memory)
    // TODO: Call API Server (gRPC/REST) to create Herd via Control Plane
    return nil
}
