package cmd

import (
	"github.com/spf13/cobra"
	"log"
)

// AuditCmd represents the "test" CLI command
var AuditCmd = &cobra.Command{
	Use:   "audit",
	Short: "Audit dags with unit tests of features against golden data",
	Run: func(cmd *cobra.Command, args []string) {
		log.Println("🧪 Audit not implemented yet — validating against golden files.")
	},
}
