package cmd

import (
	"github.com/spf13/cobra"
	"log"
)

// StatusCmd represents the "status" CLI command
var StatusCmd = &cobra.Command{
	Use:   "status",
	Short: "Show status and lineage for specific runs",
	Run: func(cmd *cobra.Command, args []string) {
		log.Println("📈 Status not implemented yet — showing run and lineage soon.")
	},
}
