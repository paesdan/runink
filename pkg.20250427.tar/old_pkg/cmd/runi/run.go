package cmd

import (
	"github.com/spf13/cobra"
	"log"
)

// RunCmd represents the "run" CLI command
var RunCmd = &cobra.Command{
	Use:   "run",
	Short: "Execute a compiled DAG at runtime",
	Run: func(cmd *cobra.Command, args []string) {
		log.Println("🚀 Run not implemented yet — soon running DAGs at scale.")
	},
}
