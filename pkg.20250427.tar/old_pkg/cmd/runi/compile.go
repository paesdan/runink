package runi

import (
    "fmt"

    "github.com/spf13/cobra"
)

var compileCmd = &cobra.Command{
    Use:   "compile",
    Short: "Compile DSL scenario into Go DAG pipeline",
    Run: func(cmd *cobra.Command, args []string) {
        fmt.Println("Compiling scenario... (stub)")
    },
}
