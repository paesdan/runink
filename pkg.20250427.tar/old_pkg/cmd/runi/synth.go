package cmd

import (
	"github.com/spf13/cobra"
	"log"
)

// SynthCmd represents the "synth" CLI command
var SynthCmd = &cobra.Command{
	Use:   "synth",
	Short: "Generate synthetic golden data based on contract",
	Run: func(cmd *cobra.Command, args []string) {
		log.Println("✨ Synth not implemented yet — generating golden data soon.")
	},
}
