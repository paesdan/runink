package cmd

import (
	"github.com/spf13/cobra"
	"log"
)

// HerdCmd represents the "herd" CLI command
var HerdCmd = &cobra.Command{
	Use:   "herd",
	Short: "Manage Herds (domains, quotas, governance)",
	Run: func(cmd *cobra.Command, args []string) {
		log.Println("🐑 Herd not implemented yet — soon you can bootstrap herds.")
	},

	cmd.AddCommand(herdctl.NewCreateCommand())
    cmd.AddCommand(herdctl.NewDeleteCommand())
    cmd.AddCommand(herdctl.NewUpdateCommand())
    cmd.AddCommand(herdctl.NewListCommand())

    return cmd
}
