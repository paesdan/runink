package cmd

import (
	"github.com/spf13/cobra"
	"github.com/runink/pkg/secrets"
)

var secretsCmd = &cobra.Command{
	Use:   "secrets",
	Short: "Manage secrets via Runink secure Raft store",
}

var putCmd = &cobra.Command{
	Use:   "put",
	Short: "Put a new secret or version",
	Run: func(cmd *cobra.Command, args []string) {
		// TODO CLI wire-up
	},
}

var getCmd = &cobra.Command{
	Use:   "get",
	Short: "Retrieve a secret (latest or version)",
	Run: func(cmd *cobra.Command, args []string) {
		// TODO CLI wire-up
	},
}

func init() {
	secretsCmd.AddCommand(putCmd)
	secretsCmd.AddCommand(getCmd)
	// more subcommands like list, delete
}
