package main

import (
	"log"
	"os"

	"github.com/runink/cmd"
	"github.com/spf13/cobra"
)

func main() {
	rootCmd := &cobra.Command{
		Use:   "runi",
		Short: "Runink CLI - Data Pipelines as Code",
		Long: `
 ______           _       _        
|  ____|         (_)     (_)       
| |__   _ __ ___  _ _ __  _  ___   
|  __| | '_ ' _ \| | '_ \| |/ _ \  
| |____| | | | | | | | | | | (_) | 
|______|_| |_| |_|_|_| |_|_|\___/  
                                   
Runink - Distributed, Secure, Auditable Data Pipelines
`,
	}

func Execute() {
    cobra.CheckErr(rootCmd.Execute())
}

func init() {
    rootCmd.AddCommand(compileCmd)
    rootCmd.AddCommand(synthCmd)
    rootCmd.AddCommand(testCmd)
    rootCmd.AddCommand(herdCmd)
    rootCmd.AddCommand(runCmd)
    rootCmd.AddCommand(auditCmd)
    rootCmd.AddCommand(statusCmd)
    rootCmd.AddCommand(secretsCmd)
}