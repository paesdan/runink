package compile

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/runink/pkg/compiler"
	"github.com/runink/pkg/contract"
	"github.com/runink/pkg/dsl"
	"github.com/runink/pkg/envloader"
)

type CompileOptions struct {
	ScenarioPath string
	ContractPath string
	EnvPath      string
	OutputPath   string
}

// OrchestrateCompile is the CLI entrypoint to compile a feature+contract into a DAG.
func OrchestrateCompile(opts CompileOptions) error {
	// Step 1: Load .env file (optional, for sinks, sources, etc.)
	envVars, err := envloader.LoadFromFile(opts.EnvPath)
	if err != nil {
		return fmt.Errorf("failed to load env file: %w", err)
	}

	// Step 2: Parse DSL (Feature + Scenario)
	scenario, err := dsl.ParseFeatureFile(opts.ScenarioPath)
	if err != nil {
		return fmt.Errorf("failed to parse scenario DSL: %w", err)
	}

	// Step 3: Parse Contract (AST + Metadata)
	contractMeta, err := contract.ParseContractFile(opts.ContractPath)
	if err != nil {
		return fmt.Errorf("failed to parse contract file: %w", err)
	}

	// Step 4: Compile into DAG
	dag, err := compiler.CompileScenario(scenario, contractMeta, envVars)
	if err != nil {
		return fmt.Errorf("failed to compile DAG: %w", err)
	}

	// Step 5: Emit generated DAG code
	if err := emitDAGToFile(dag, opts.OutputPath); err != nil {
		return fmt.Errorf("failed to emit DAG code: %w", err)
	}

	fmt.Println("✅ Compilation successful! DAG written to", opts.OutputPath)
	return nil
}

// emitDAGToFile writes the DAG Go source code to the output path.
func emitDAGToFile(dag *compiler.DAG, outputPath string) error {
	code, err := compiler.RenderDAG(dag)
	if err != nil {
		return fmt.Errorf("failed to render DAG code: %w", err)
	}

	if err := os.MkdirAll(filepath.Dir(outputPath), 0755); err != nil {
		return fmt.Errorf("failed to create output directory: %w", err)
	}

	return os.WriteFile(outputPath, []byte(code), 0644)
}
