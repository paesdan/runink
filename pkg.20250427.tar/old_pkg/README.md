Packages structure:

```plaintext
pkg/
├── cmd/runi/                  → CLI entrypoints (thin shells only)
│    ├── herdctl.go            # Herd control plane management
│    ├── agentctl.go           # Runi agent management
│    ├── slicectl.go           # Worker slice operations
│    ├── compile.go            # compile: Feature + Contract -> DAG
│    ├── synth.go              # synth: Generate synthetic golden data
│    ├── herd.go               # herd: Herd bootstrapper
│    ├── run.go                # run: Execute compiled DAG
│    ├── audit.go              # audit: Validate golden files/version diffs
│    ├── status.go             # status: Run status and lineage
│    ├── secrets.go            # secrets: Put/Get/List/Delete/Version
│    ├── herdctl/
│    │    └── orchestrator.go  # Herd management logic (Create/Update/Delete/List/Quota)
│    ├── agentctl/
│    │    └── orchestrator.go  # Runi agent interaction (List/Status/Drain/Register)
│    ├── slicectl/
│    │    └── orchestrator.go  # Worker slice inspection (List/Logs/Cancel)
│    ├── builder/
│    │    ├── orchestrator.go   # *NEW*: Only CLI orchestration (no real logic here)
│    ├── synth/
│    │    └── orchestrator.go   # *NEW*: CLI orchestrator for synth
│    ├── audit/
│    │    └── orchestrator.go   # *NEW*: CLI orchestrator for audit
│    ├── herd/
│    │    └── orchestrator.go   # *NEW*: CLI orchestrator for herd
│    ├── run/
│    │    └── orchestrator.go   # *NEW*: CLI orchestrator for run
│    ├── run/
│    │    └── orchestrator.go   # *NEW*: CLI orchestrator for run
│    └── status/
│         └── orchestrator.go   # *NEW*: CLI orchestrator for status
│
├── buildctl/                     → DAG Compiler core
│    ├── builder.go              # DAG builder
│    ├── compliance.go           # TLS, SLA injections
│    ├── dag.go                  # Core DAG structs and nodes
│    ├── graphviz.go             # Graphviz DAG output
│    ├── hooks.go                # Compliance, SLA hooks
│    ├── metadata.go             # Compilation metadata
│    ├── optimizer.go            # DAG optimizations (pipes, streaming)
│    ├── parser.go               # Annotation extractor
│    ├── step.go                 # Step structs and helpers
│    ├── stream.go               # Streaming pipeline render
│    ├── contract.go             # Main loader/parser
│    ├── feature.go              # Feature struct definitions
│    ├── steps_dsl.go            # Main DSL parser
│    ├── validate_dsl.go         # *RENAMED*: DSL validation
│    ├── metadata.go             # DSL metadata structs
│    └── utils.go                # DAG utilities
│
├── secrets/                    → Secrets service
│    ├── manager.go              # Secrets manager, Store interface
│    ├── store.go                # Badger-backed secret store
│    ├── crypto.go               # AES-GCM encryption
│    ├── reencrypt.go            # Master key rotation
│    ├── models.go               # Secret and version structs
│    ├── audit.go                # Secrets access audit trail
│    ├── rbac.go                 # Herd boundary enforcement
│    └── utils.go                # Utility helpers
│
├── raftstore/                   → Raft-based State Management
│    ├── client.go               # Raft client
│    ├── metadata.go             # Registration metadata
│    ├── register.go             # Herd/Feature registration logic
│    ├── snapshot.go             # Durable snapshots
│    ├── validate_raftstore.go   # *RENAMED*: Validation helpers
│    └── utils.go                # Helper functions
│
├── hashing/                     → Hashing and signing utilities
│    ├── hashing.go              # SHA256, LineageID hashing
│    ├── signer.go               # mTLS future support
│    ├── metadata.go             # Metadata enrich structs
│    └── utils.go                # Encoding utilities
│
├── badger/                      → Badger database wrappers
│    ├── store.go                # Open/Put/Get/Delete helpers
│    ├── keys.go                 # Key conventions
│    ├── snapshot.go             # Snapshot management
│    ├── options.go              # BadgerDB options
│    ├── metadata.go             # Metadata structs
│    └── utils.go                # Serialization helpers
│
├── golden/                      # *NEW*: Synthetic data, golden tests
│    ├── fakers.go
│    ├── golden_validator.go
│    └── testdata/
│         ├── example.input.json
│         └── example.golden.json
│
├── runictl/                    → Agent daemon (slice orchestration)
│    ├── agent.go               # Main agent lifecycle
│    ├── cgroup.go              # Cgroup creation and enforcement
│    ├── envloader.go           # Environment variable injection
│    ├── execution.go           # Launch transform stages (pipes, io.Reader/io.Writer)
│    ├── lineage.go             # Emit lineage events per slice step
│    ├── metadata.go            # Builder metadata structs
│    ├── monitor.go             # Prometheus metrics, SLA violations
│    ├── namespace.go           # Linux namespaces utilities
│    ├── parser.go              # Parser Functions
│    ├── pipes.go               # Pipe chaining between stages
│    ├── preemption.go          # Herd quota monitor, preempt slices
│    ├── runner.go              # SliceRunner: Execute single pipeline step
│    ├── sandbox_agent.go       # High-level cgroup/namespace orchestrator
│    ├── sandbox_slice.go       # Low-level namespace/cgroup creation
│    ├── secrets.go             # Agent-side secrets fetch and inject
│    ├── heartbeat.go           # Node health heartbeat
│    └── validate_dag.go        # *RENAMED*: DAG validation helpers
│    ├── retry.go                # Retry policy engine
│    └── backoff.go              # Exponential, linear backoff
│    ├── scheduler.go           # Scheduling loop
│    ├── solver.go              # Constraint solver engine
│    ├── placement.go           # Node scoring and selection
│    ├── affinity.go            # Fine-grained node affinity scoring logic 
│    ├── constraints.go         # Fine-grained node constraints scoring logic 
│    ├── validate_request.go    # *RENAMED*: Request validation helpers
│    └── utils.go               # Placement helper functions
│
├── apiserver/                   → External API server
│    ├── server.go               # gRPC/HTTP server
│    ├── router.go               # Route registration
│    ├── handlers.go             # API handlers
│    ├── registry.go             # Node registry
│    ├── middleware.go           # Auth middleware
│    ├── validate_api.go         # *RENAMED*: API input validation
│    ├── herd/                # *NEW*: Handler group for Herd APIs
│    │    ├── create.go
│    │    ├── delete.go
│    │    └── update.go
│    ├── pipeline/            # *NEW*: Handler group for Pipeline APIs
│    │    ├── create.go
│    │    ├── status.go
│    │    └── lineage.go
│    ├── secrets/             # *NEW*: Handler group for Secrets APIs
│    │    ├── put.go
│    │    ├── get.go
│    │    └── list.go
│    └── common/              # Optional: shared API response models
│         ├── response.go
│         └── errors.go
│
├── rbac/                        → RBAC enforcement
│    ├── policy.go               # Role/Action/Herd policies
│    ├── checker.go              # Permission validator
│    ├── scopes.go               # JWT scope parsing
│    └── middleware.go           # HTTP/gRPC middleware
│
----
│
├── governance/                  → Lineage and metadata store
│    ├── metadata.go             # Run/Lineage core structs
│    ├── lineage.go              # Lineage emission
│    ├── storage.go              # Raft/Badger-backed metadata store
│    ├── graph.go                # Build Lineage Graphs from Metadata
│    ├── exporter.go             # Export lineage (DOT, RDF, etc)
│    ├── rdf.go                  # Export contracts, features, lineage as RDF
│    ├── semantic_query.go       # SQL-like Query Engine for metadata
│    ├── metrics.go              # Prometheus emitters
│    ├── logs.go                 # Fluentd/Promtail logs
│    ├── tracing.go              # OpenTelemetry spans
│    └── hooks.go                # SLA alert hooks
│
├── security/                    → Security-related utilities
│    ├── changelog.go            # Generate changelogs
│    ├── approvals.go            # Contract/Scenario Governance Flow
│    ├── redactions.go           # PII Redaction handling
│    ├── sbom.go                 # SBOM generation
│    ├── signer.go               # Artifact signing
│    ├── scanner.go              # Vulnerability scanning
│    ├── token.go                # Mint short-lived tokens
│    └── api.go                  # gRPC/HTTP API handlers│
│
├── conformed/                   → Standard pipeline steps 
     ├── normalize.go
     ├── validate_sin.go
     ├── enrich_metadata.go
     └── utils.go
```

## Agent Execution model:

### Flowchart
```plaintext
flowchart TD
  A[DAG Loaded] --> B[Agent.RunDAG()]
  B --> C[RunStep(Node)]
  C --> D[Sandbox.Start()]
  D --> E[Execute Step Action]
  E --> F[Emit Lineage]
  E --> G[Update SLA Metrics]
  F --> H[Cleanup Sandbox]
  G --> H
```

### Components architecture
```plaintext
[ User (CLI / UI) ]
          |
    (gRPC / TLS)
          |
[ Herd Control Plane (API Servers)]
          |
+------------------------+
| Raft Layer (etcd/raft)  |
| + Badger as WAL/State   |
+------------------------+
          |
[Barn (Cluster State Store)]
 - Herd definitions
 - Slice execution plans
 - Secrets
 - Contracts
 - Lineage Metadata
 - Annotations from DSL tags
          |
  /    |      \ 
Agent1 Agent2  Agent3
|        |         |
SliceA  SliceB   SliceC
(executes Go code, emits lineage, metrics)
```

## Definition

Let us create each necessary file per category. Starting with the following:

```
 ├── agent/              → Agent daemon: slice orchestration on node
 │    ├── agent.go          # Main agent lifecycle (register, fetch, execute)
 │    ├── runner.go         # SliceRunner: execute single pipeline step
 │    ├── sandbox.go        # Cgroups + Namespaces setup per slice
 │    ├── monitor.go        # Prometheus metrics, SLA violations
 │    ├── lineage.go        # Emit lineage events per slice step
 │    ├── preemption.go     # Herd quota monitor and slice killer
 │    ├── secrets.go        # Agent-side secrets fetching and injection
 │    ├── heartbeat.go      # Node health heartbeat sender
 │    └── validate.go       # DAG validation helpers
```

With our metadata definition coming from :

```
import (
	"github.com/runink/pkg/envloader"
	"github.com/runink/pkg/herdloader"
)

```

Scaffold *agent/preemption.go* next. Each go program must be written based on the following programing concepts, create placeholders with detailed information for our next development iteration:

+++


# 🧠 Runink Functional Programming Excellence

A guide to **how Runink applies modern Functional Programming, Data-Oriented Design (DOD), Zero-Copy Pipelines, and Declarative Scheduling** using Go and Linux primitives — serving as the architectural backbone for performant, auditable, and scalable pipelines.

---

## 1. Functional Programming Approach

> _Compose transformations as pure functions without side effects._

### Core Concept
In Runink, every pipeline stage (`@step`) is designed as a **pure function** — mapping structured inputs to outputs without mutating external state. This enables composability, testability, concurrency, and safe retries in distributed executions.

### Runink Optimizations
- Design transforms as pure Go functions:

  ```go
  func NormalizeEmails(users []contracts.User) []contracts.User {
    out := make([]contracts.User, len(users))
    for i, u := range users {
      u.Email = strings.ToLower(strings.TrimSpace(u.Email))
      out[i] = u
    }
    return out
  }
  ```

- Compose `@step` chains as functional pipelines.
- Golden files snapshot pure inputs/outputs for regression-safe testing.

### Benefits
- **Testability**: Easy golden file testing.
- **Concurrency-Safe**: No shared state across slices.
- **Idempotence**: Retryability without side effects.

---

## 2. Data-Oriented Design (DOD)

> _Design memory layout for the CPU, not for developer convenience._

### Core Concept
Runink prioritizes **memory predictability, cache locality**, and **low-GC pressure** by designing slices for how data flows through the CPU: flat structs, batch preallocation, minimal pointer chasing, and columnar access when beneficial.

### Runink Optimizations
- Use `sync.Pool` and flat memory layouts:

  ```go
  var users = make([]contracts.User, 0, 10000)
  var pool = sync.Pool{New: func() interface{} { return new(contracts.User) }}

  func LoadUsers(r io.Reader) ([]contracts.User, error) {
    decoder := json.NewDecoder(r)
    for decoder.More() {
      user := pool.Get().(*contracts.User)
      if err := decoder.Decode(user); err != nil {
        return nil, err
      }
      users = append(users, *user)
      pool.Put(user)
    }
    return users, nil
  }
  ```

- Preallocate based on schema contract hints (`maxRecords`).
- Avoid nested structs unless semantically necessary.

### Benefits
- **Higher CPU throughput**: Better cache efficiency.
- **Reduced GC overhead**: Fewer heap allocations.
- **Stable performance** under high concurrency.

---

## 3. Zero-Copy and Streaming Pipelines

> _Process data as it flows, without materializing full datasets._

### Core Concept
Instead of `[]Record -> Transform -> []Record`, Runink slices operate over **byte streams** using `io.Reader`, `io.Writer`, `os.Pipe()`, and native Go concurrency — enabling constant memory usage, backpressure control, and massive scalability.

### Runink Optimizations
- Chain pipeline stages via readers and writers:

  ```go
  func ValidateUser(r io.Reader, w io.Writer) error {
    decoder := json.NewDecoder(r)
    encoder := json.NewEncoder(w)

    for decoder.More() {
      var user contracts.User
      if err := decoder.Decode(&user); err != nil {
        return err
      }
      if isValid(user) {
        encoder.Encode(user)
      }
    }
    return nil
  }
  ```

- Use Linux pipes for intra-slice streaming:

  ```go
  r1, w1 := os.Pipe()
  r2, w2 := os.Pipe()

  go Normalize(r0, w1) // Input -> Step 1
  go Enrich(r1, w2)    // Step 1 -> Step 2
  go Sink(r2, out)     // Step 2 -> Final sink
  ```

- Tee outputs for DLQ handling using `io.MultiWriter()`.

### Benefits
- **Constant memory** for arbitrarily large streams.
- **Built-in backpressure**: Natural flow control.
- **True streaming**: No blocking on entire batch loads.

---

## 4. Declarative Scheduling with Constraint Propagation

> _Specify resource needs, not imperative instructions._

### Core Concept
Rather than manually picking nodes, Runink slices **declare** resource requirements (CPU, memory, affinity, quota, etc.) and the scheduler **solves placement** based on Raft-backed cluster state. This ensures reproducible, fair, and auditable execution decisions.

### Runink Optimizations
- Capture constraints declaratively in `.dsl`:

  ```gherkin
  @step("RunLLMValidation")
  @requires(cpu="2", memory="512Mi", label="gpu")
  ```

- Represent placement as structured constraints in Go:

  ```go
  type PlacementConstraint struct {
    CPU     int
    Memory  int
    Labels  map[string]string
    Affinity string
  }
  ```

- Solve placement per slice at runtime:

  ```go
  func Schedule(sliceID string, constraints PlacementConstraint) (Node, error) {
    nodes := ListAvailableNodes()
    for _, n := range nodes {
      if n.Meets(constraints) {
        return n, nil
      }
    }
    return Node{}, errors.New("no suitable node found")
  }
  ```

- Persist placement decisions in Raft logs for replayability.

### Benefits
- **Deterministic placement**: Predictable and auditable.
- **Multi-tenant fairness**: Respect Herd quotas and boundaries.
- **Safe retries**: Constraints enforce idempotent re-scheduling.

---

# 📋 Summary Table

| Core Idea                        | Linux/Go Primitives Used             | Key Advantages                                    |
|-----------------------------------|--------------------------------------|--------------------------------------------------|
| Functional Programming            | Pure Go functions                   | Testability, retry safety, parallelism           |
| Data-Oriented Design              | `sync.Pool`, flat structs            | Cache locality, low GC, higher throughput        |
| Zero-Copy Streaming               | `io.Reader`, `os.Pipe`, `io.Writer`  | Constant memory, natural backpressure            |
| Declarative Scheduling            | Raft, constraint structs             | Deterministic scheduling, multi-tenant isolation |

---

# ✅ Reference Best Practices

- Always prefer **pure functions** for pipeline steps.
- Preallocate and reuse **buffers** via `sync.Pool`.
- Prefer **streamed pipelines** instead of batch materialization.
- Capture **placement constraints declaratively** in `.dsl`.
- Persist **state decisions into Raft** for full replayability.
+++