package herdloader

// HerdConfig defines a Herd boundary's enforced policy and runtime quotas
type HerdConfig struct {
	Name        string      `json:"name" yaml:"name"`
	Description string      `json:"description" yaml:"description"`
	Quotas      Quotas      `json:"quotas" yaml:"quotas"`
	Security    Security    `json:"security" yaml:"security"`
	Governance  Governance  `json:"governance" yaml:"governance"`
	Compliance  Compliance  `json:"compliance" yaml:"compliance"`
	Access      AccessRules `json:"access" yaml:"access"`
	Lineage     LineageSpec `json:"lineage" yaml:"lineage"`
}

// Quotas defines CPU/mem/runs quotas for a Herd
type Quotas struct {
	CPU         int    `json:"cpu" yaml:"cpu"`
	Memory      string `json:"memory" yaml:"memory"`
	MaxRuns     int    `json:"max_runs_per_day" yaml:"max_runs_per_day"`
	MaxCPU      string `json:"max_cpu_per_run" yaml:"max_cpu_per_run"`
	MaxMemory   string `json:"max_mem_per_run" yaml:"max_mem_per_run"`
	TTLSeconds  int    `json:"ttl_seconds" yaml:"ttl_seconds"`
}

// Security defines Herd runtime security policies
type Security struct {
	TLSRequired bool `json:"tls_required" yaml:"tls_required"`
}

// Governance defines Herd classification and data governance policies
type Governance struct {
	QualityTier      string `json:"quality_tier" yaml:"quality_tier"`
	Classification   string `json:"classification" yaml:"classification"`
	AccessPolicy     string `json:"access_policy" yaml:"access_policy"`
	GovernancePolicy string `json:"governance_policy" yaml:"governance_policy"`
}

// Compliance defines compliance expectations for the Herd
type Compliance struct {
	OperationalStatus   string `json:"operational_status" yaml:"operational_status"`
	RecoveryStatus      string `json:"recovery_status" yaml:"recovery_status"`
	DataSecurityStatus  string `json:"data_security_status" yaml:"data_security_status"`
	AccessControlStatus string `json:"access_control_status" yaml:"access_control_status"`
}

// AccessRules defines RBAC permissions within a Herd
type AccessRules struct {
	Roles []Role `json:"roles" yaml:"roles"`
}

// Role represents an individual RBAC role
type Role struct {
	Name  string   `json:"name" yaml:"name"`
	Allow []string `json:"allow" yaml:"allow"`
	Deny  []string `json:"deny" yaml:"deny"`
}

// LineageSpec defines lineage and audit retention for a Herd
type LineageSpec struct {
	Enable          bool `json:"enable" yaml:"enable"`
	RetentionDays   int  `json:"retention_days" yaml:"retention_days"`
	EmitContractHash bool `json:"emit_contract_hash" yaml:"emit_contract_hash"`
}


// LineageMetadata holds enriched metadata used for hashing, lineage, and compliance tracking
type LineageMetadata struct {
	FeatureMetadata envloader.Metadata `json:"feature_metadata"`
	HerdConfig      herdloader.HerdConfig `json:"herd_config"`
	Checksum        string `json:"checksum"`
	Version         string `json:"version"`
	ContractHash    string `json:"contract_hash"`
	LineageID       string `json:"lineage_id"`
}
