package herdloader

import (
	"fmt"
	"io/ioutil"

	"gopkg.in/yaml.v2"
)

// ParseFile reads a herd YAML definition and parses into HerdConfig
func ParseFile(path string) (HerdConfig, error) {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		return HerdConfig{}, fmt.Errorf("failed to read herd file: %w", err)
	}

	var herd HerdConfig
	if err := yaml.Unmarshal(data, &herd); err != nil {
		return HerdConfig{}, fmt.Errorf("failed to unmarshal herd yaml: %w", err)
	}

	if err := ValidateHerd(herd); err != nil {
		return HerdConfig{}, fmt.Errorf("invalid herd configuration: %w", err)
	}

	return herd, nil
}
