package hashing

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"

	"github.com/runink/pkg/envloader"
	"github.com/runink/pkg/herdloader"
)

// GenerateLineageID creates a deterministic LineageID for a pipeline
func GenerateLineageID(meta envloader.Metadata) string {
	payload, _ := json.Marshal(meta)
	sum := sha256.Sum256(payload)
	return hex.EncodeToString(sum[:])
}

// ComputeFileHash computes a SHA256 hash of a file for contract integrity
func ComputeFileHash(filepath string) (string, error) {
	data, err := os.ReadFile(filepath)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:]), nil
}

// ComputeBytesHash computes SHA256 from bytes
func ComputeBytesHash(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

// GenerateFeatureKey creates a unique feature key
func GenerateFeatureKey(herd string, feature string) string {
	raw := herd + ":" + feature
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}

// GenerateSecretChecksum ensures the secret value is tamper-proof
func GenerateSecretChecksum(secret []byte) string {
	sum := sha256.Sum256(secret)
	return hex.EncodeToString(sum[:])
}


// BytesToHex encodes bytes to a lowercase hex string (e.g., 32 bytes -> 64 hex chars)
func BytesToHex(data []byte) string {
	return hex.EncodeToString(data)
}

// HexToBytes decodes a hex string back into a byte slice
func HexToBytes(s string) ([]byte, error) {
	return hex.DecodeString(s)
}

// ShortenHash returns a short form of a hash (e.g., first 8 characters for IDs)
func ShortenHash(hash string) string {
	if len(hash) < 8 {
		return hash
	}
	return hash[:8]
}

// StableJSON marshals data into a deterministic, sorted JSON byte array.
// Useful for hashing structs or maps consistently.
func StableJSON(data interface{}) ([]byte, error) {
	b, err := json.Marshal(data)
	if err != nil {
		return nil, err
	}
	return b, nil
}