package herdloader

// cleanName could normalize herd names
func cleanName(name string) string {
	// future: lowercase, trim spaces, etc.
	return name
}
