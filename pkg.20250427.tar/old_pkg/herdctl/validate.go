package herdloader

import "fmt"

// ValidateHerd checks required fields
func ValidateHerd(h HerdConfig) error {
	if h.Name == "" {
		return fmt.Errorf("herd name cannot be empty")
	}
	if h.Quotas.CPU <= 0 {
		return fmt.Errorf("herd CPU quota must be > 0")
	}
	if h.Quotas.Memory == "" {
		return fmt.Errorf("herd memory quota must be specified")
	}
	return nil
}
