// File: pkg/agent/runner.go

package agent

import (
	"context"
	"encoding/json"
	"io"
	"os"
	"sync"
	"time"
)

// Runner is responsible for executing a single pipeline slice.
// Data-Oriented Design: flat structs, preallocated pools, and streaming readers.
type Runner struct {
	bufferPool sync.Pool
}

// SlicePayload represents the input payload to launch a slice.
type SlicePayload struct {
	RunID      string
	StageID    string
	ContractID string
	SourceURI  string
	Transform  string
	SinkURI    string
}

// NewRunner initializes a new Runner instance.
func NewRunner() *Runner {
	return &Runner{
		bufferPool: sync.Pool{
			New: func() interface{} {
				// Preallocate 64KB buffers for stream reads.
				return make([]byte, 64*1024)
			},
		},
	}
}

// Launch begins the slice execution pipeline.
func (r *Runner) Launch(payloadBytes []byte) {
	var payload SlicePayload
	if err := json.Unmarshal(payloadBytes, &payload); err != nil {
		// Log bad payload, send DLQ entry (not implemented yet)
		return
	}

	go r.execute(context.Background(), payload)
}

// execute runs the end-to-end source -> transform -> sink pipeline.
func (r *Runner) execute(ctx context.Context, payload SlicePayload) {
	// Stream from Source
	srcReader, err := openSource(payload.SourceURI)
	if err != nil {
		// TODO: Send error to observability hooks
		return
	}
	defer srcReader.Close()

	// Create Transform Pipe
	pr, pw := io.Pipe()

	// Launch Transform Goroutine (stream-based)
	go func() {
		defer pw.Close()
		_ = applyTransform(payload.Transform, srcReader, pw)
	}()

	// Launch Sink (consumer) from Pipe Reader
	_ = writeSink(payload.SinkURI, pr)
}

// openSource opens a source URI into a streaming reader.
func openSource(uri string) (io.ReadCloser, error) {
	// Placeholder: implement file://, http://, kafka:// etc. stream readers.
	return os.Open(uri)
}

// applyTransform applies the transformation logic over a stream.
func applyTransform(name string, r io.Reader, w io.Writer) error {
	// Placeholder: Route based on transform name.
	// Example: NormalizeEmails, ValidateSIN, etc.
	buf := make([]byte, 4096)
	for {
		n, err := r.Read(buf)
		if n > 0 {
			// For now: simple passthrough (identity transform)
			_, _ = w.Write(buf[:n])
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
	}
	return nil
}

// writeSink writes the transformed data to the final sink.
func writeSink(uri string, r io.Reader) error {
	// Placeholder: implement file://, kafka://, db:// sinks.
	out, err := os.Create(uri)
	if err != nil {
		return err
	}
	defer out.Close()

	_, err = io.Copy(out, r)
	return err
}
