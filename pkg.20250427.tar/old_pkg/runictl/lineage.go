// File: pkg/agent/lineage.go

package agent

import (
	"sync"
	"time"
)

// LineageEmitter collects and emits lineage events per slice step.
// Data-Oriented Design (DOD): flat, cache-friendly structs, minimal allocations.
type LineageEmitter struct {
	mu        sync.Mutex
	events    []LineageEvent
}

// LineageEvent defines a single lineage record for a step.
type LineageEvent struct {
	RunID        string
	StageID      string
	ContractID   string
	SourceURI    string
	SinkURI      string
	Transform    string
	RecordsIn    int64
	RecordsOut   int64
	StartTime    time.Time
	EndTime      time.Time
	Success      bool
	ErrorMessage string
}

// NewLineageEmitter initializes a lineage emitter.
func NewLineageEmitter() *LineageEmitter {
	return &LineageEmitter{
		events: make([]LineageEvent, 0, 1024), // Preallocate lineage buffer
	}
}

// RecordEvent appends a lineage event.
func (l *LineageEmitter) RecordEvent(event LineageEvent) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.events = append(l.events, event)
}

// Flush returns all recorded events and resets buffer.
func (l *LineageEmitter) Flush() []LineageEvent {
	l.mu.Lock()
	defer l.mu.Unlock()

	out := make([]LineageEvent, len(l.events))
	copy(out, l.events)
	l.events = l.events[:0]
	return out
}

// ExportEvents exports lineage to external store (raftstore, file, etc.).
func (l *LineageEmitter) ExportEvents() error {
	// Placeholder: integrate Raft-backed metadata store here
	return nil
}
