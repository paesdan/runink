// File: pkg/slice/namespace.go

package slice

import (
	"fmt"
	"syscall"
)

// NamespaceSpec defines which Linux namespaces to apply.
// Data-Oriented Design (DOD): flat struct, explicit flags.
type NamespaceSpec struct {
	UnshareUser   bool
	UnsharePID    bool
	UnshareMount  bool
	UnshareNetwork bool
}

// SetupNamespaces unshares requested namespaces for isolation.
func SetupNamespaces(spec NamespaceSpec) error {
	var flags uintptr

	if spec.UnshareUser {
		flags |= syscall.CLONE_NEWUSER
	}
	if spec.UnsharePID {
		flags |= syscall.CLONE_NEWPID
	}
	if spec.UnshareMount {
		flags |= syscall.CLONE_NEWNS
	}
	if spec.UnshareNetwork {
		flags |= syscall.CLONE_NEWNET
	}

	if flags == 0 {
		return fmt.Errorf("no namespaces selected for unsharing")
	}

	if err := syscall.Unshare(flags); err != nil {
		return fmt.Errorf("namespace unshare failed: %w", err)
	}

	return nil
}

// SetupMinimalIsolation sets up minimal safe namespaces for a slice.
func SetupMinimalIsolation() error {
	spec := NamespaceSpec{
		UnshareUser:  true,
		UnsharePID:   true,
		UnshareMount: true,
	}
	return SetupNamespaces(spec)
}

// SetupFullIsolation sets up user, pid, mnt, and net isolation for slices needing network control.
func SetupFullIsolation() error {
	spec := NamespaceSpec{
		UnshareUser:   true,
		UnsharePID:    true,
		UnshareMount:  true,
		UnshareNetwork: true,
	}
	return SetupNamespaces(spec)
}
