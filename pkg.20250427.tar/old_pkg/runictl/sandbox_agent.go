// File: pkg/agent/sandbox.go

package agent

import (
	"fmt"
	"os"
	"syscall"
)

// Sandbox provides cgroup and namespace isolation per slice execution.
// Data-Oriented Design (DOD) applied: simple structs, flat memory layout.
type Sandbox struct {
	CgroupPath   string
	NamespacePID int
	ResourceSpec ResourceSpec
}

// ResourceSpec defines CPU and memory limits for a slice.
type ResourceSpec struct {
	CPUShares int    // Relative CPU weight
	MemoryMax int64  // Max memory in bytes
	HerdName  string // Herd namespace
}

// NewSandbox sets up namespaces and cgroups for a slice.
func NewSandbox(spec ResourceSpec) (*Sandbox, error) {
	sb := &Sandbox{
		ResourceSpec: spec,
	}

	// Prepare cgroup (placeholder, no-op yet)
	if err := sb.setupCgroup(); err != nil {
		return nil, fmt.Errorf("setup cgroup failed: %w", err)
	}

	return sb, nil
}

// setupCgroup applies resource constraints.
func (s *Sandbox) setupCgroup() error {
	// Placeholder: Mount cgroup2 filesystem and write limits (cpu.shares, memory.max).
	// Avoid kernel fallback to cgroup v1.
	// Paths like: /sys/fs/cgroup/herds/<herd>/<slice>
	return nil
}

// IsolateFork forks a new process into fresh namespaces.
func (s *Sandbox) IsolateFork(execFn func() error) error {
	attr := &syscall.SysProcAttr{
		Cloneflags: syscall.CLONE_NEWUSER |
			syscall.CLONE_NEWPID |
			syscall.CLONE_NEWNET |
			syscall.CLONE_NEWNS,
		Credential: &syscall.Credential{
			Uid: 100000, // Ephemeral UID mapping (example)
			Gid: 100000, // Ephemeral GID mapping (example)
		},
	}

	r, w, err := os.Pipe()
	if err != nil {
		return err
	}
	defer r.Close()
	defer w.Close()

	// Fork using clone + exec isolation.	
	pid, err := syscall.ForkExec("/proc/self/exe", []string{"slice-child"}, &syscall.ProcAttr{
		Files: []uintptr{0, 1, 2, r.Fd()},
		Sys:   attr,
	})
	if err != nil {
		return err
	}

	s.NamespacePID = pid
	return nil
}

// Teardown releases namespaces and cgroup resources.
func (s *Sandbox) Teardown() error {
	// Placeholder: Remove cgroup slice limits and cleanup namespaces if needed.
	return nil
}

// File: pkg/slice/sandbox.go

package slice

import (
	"fmt"
	"os/exec"
)

// SandboxConfig defines the settings for slice isolation.
// Data-Oriented Design (DOD): flat struct, tight memory layout.
type SandboxConfig struct {
	SliceName    string
	CPUQuotaUSec int64
	MemoryBytes  int64
	IsolateNet   bool
}

// SetupSandbox creates isolated namespace and cgroup for a slice.
func SetupSandbox(cfg SandboxConfig) error {
	// 1. Unshare namespaces
	if cfg.IsolateNet {
		if err := SetupFullIsolation(); err != nil {
			return fmt.Errorf("sandbox: failed to setup full namespaces: %w", err)
		}
	} else {
		if err := SetupMinimalIsolation(); err != nil {
			return fmt.Errorf("sandbox: failed to setup minimal namespaces: %w", err)
		}
	}

	// 2. Setup cgroup constraints
	cgroupCfg := CgroupConfig{
		SliceName:    cfg.SliceName,
		CPUQuotaUSec: cfg.CPUQuotaUSec,
		MemoryBytes:  cfg.MemoryBytes,
	}
	if err := SetupCgroup(cgroupCfg); err != nil {
		return fmt.Errorf("sandbox: failed to setup cgroup: %w", err)
	}

	return nil
}

// AttachToSandbox attaches a child process to the slice sandbox.
func AttachToSandbox(sliceName string, cmd *exec.Cmd) error {
	if cmd.Process == nil {
		return fmt.Errorf("sandbox: cmd.Process is nil")
	}
	pid := cmd.Process.Pid
	if err := AttachPID(sliceName, pid); err != nil {
		return fmt.Errorf("sandbox: failed to attach pid: %w", err)
	}
	return nil
}

// CleanupSandbox cleans up resources after slice completion.
func CleanupSandbox(sliceName string) error {
	if err := CleanupCgroup(sliceName); err != nil {
		return fmt.Errorf("sandbox: failed to cleanup cgroup: %w", err)
	}
	// Namespace unmounting handled by OS when process exits.
	return nil
}


// Notes:
// - Future: setup additional namespaces like mnt propagation.
// - Future: integrate OOM kill handlers to enforce memory limits strictly.
// - Future: integrate PID namespace tracking per slice.

// Always favor simple structs, channels, io.Pipe() connections for maximum cache locality and zero-copy design.
