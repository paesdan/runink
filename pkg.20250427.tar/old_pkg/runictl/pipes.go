// File: pkg/slice/pipes.go

package slice

import (
	"fmt"
	"io"
	"os"
)

// PipePair holds a reader and writer pair for stage chaining.
// Data-Oriented Design (DOD): flat struct, no pointer indirection.
type PipePair struct {
	Reader *os.File
	Writer *os.File
}

// CreatePipePair creates an OS-level pipe.
func CreatePipePair() (*PipePair, error) {
	r, w, err := os.Pipe()
	if err != nil {
		return nil, fmt.Errorf("failed to create pipe: %w", err)
	}
	return &PipePair{Reader: r, Writer: w}, nil
}

// ClosePipe safely closes both ends of a PipePair.
func (p *PipePair) ClosePipe() error {
	var errs []error
	if err := p.Reader.Close(); err != nil {
		errs = append(errs, err)
	}
	if err := p.Writer.Close(); err != nil {
		errs = append(errs, err)
	}
	if len(errs) > 0 {
		return fmt.Errorf("pipe close errors: %v", errs)
	}
	return nil
}

// TeePipe duplicates the data from a Reader to two Writers.
// Useful for DLQ/valid pipelines.
func TeePipe(src io.Reader, w1, w2 io.Writer) error {
	buf := make([]byte, 4096)
	for {
		n, err := src.Read(buf)
		if n > 0 {
			if _, err1 := w1.Write(buf[:n]); err1 != nil {
				return err1
			}
			if _, err2 := w2.Write(buf[:n]); err2 != nil {
				return err2
			}
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
	}
	return nil
}
