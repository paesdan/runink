// File: pkg/agent/monitor.go

package agent

import (
	"sync"
	"time"
)

// MetricsMonitor collects and exports agent and slice metrics.
// Data-Oriented Design (DOD): favor flat structs, minimal allocations.
type MetricsMonitor struct {
	mu             sync.Mutex
	totalSlices    int64
	succeededSlices int64
	failedSlices   int64
	heartbeatCPU    float64
	heartbeatMemory float64
	sliceLatency   []LatencySample
}

// LatencySample records per-slice SLA timings.
type LatencySample struct {
	StageID   string
	Duration  time.Duration
	Timestamp time.Time
}

// NewMetricsMonitor initializes a metrics collector.
func NewMetricsMonitor() *MetricsMonitor {
	return &MetricsMonitor{
		sliceLatency: make([]LatencySample, 0, 512), // Preallocate typical buffer
	}
}

// RecordSliceStart increments total slice count.
func (m *MetricsMonitor) RecordSliceStart() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.totalSlices++
}

// RecordSliceSuccess increments succeeded slice count.
func (m *MetricsMonitor) RecordSliceSuccess() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.succeededSlices++
}

// RecordSliceFailure increments failed slice count.
func (m *MetricsMonitor) RecordSliceFailure() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.failedSlices++
}

// RecordSliceLatency adds a new latency sample.
func (m *MetricsMonitor) RecordSliceLatency(stageID string, d time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.sliceLatency = append(m.sliceLatency, LatencySample{
		StageID:   stageID,
		Duration:  d,
		Timestamp: time.Now(),
	})
}

// CollectCPUUsage samples current CPU usage.
func (m *MetricsMonitor) CollectCPUUsage() float64 {
	// Placeholder: integrate with /proc/stat parsing
	return m.heartbeatCPU
}

// CollectMemoryUsage samples current memory usage.
func (m *MetricsMonitor) CollectMemoryUsage() float64 {
	// Placeholder: integrate with /proc/meminfo parsing
	return m.heartbeatMemory
}

// RunningSlices returns currently active slices.
func (m *MetricsMonitor) RunningSlices() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return int(m.totalSlices - m.succeededSlices - m.failedSlices)
}

// ResetLatencyWindow trims old SLA records.
func (m *MetricsMonitor) ResetLatencyWindow(maxAge time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	
	cutoff := time.Now().Add(-maxAge)
	n := 0
	for _, sample := range m.sliceLatency {
		if sample.Timestamp.After(cutoff) {
			m.sliceLatency[n] = sample
			n++
		}
	}
	m.sliceLatency = m.sliceLatency[:n]
}
