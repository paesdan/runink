// File: pkg/agent/secrets.go

package agent

import (
	"sync"
	"time"
)

// SecretsManager fetches and injects secrets dynamically before slice execution.
// Data-Oriented Design (DOD): flat structs, minimal allocations.
type SecretsManager struct {
	mu        sync.Mutex
	secrets   map[string]string // cache: secretKey -> secretValue
	expiresAt time.Time
	fetchFunc func(secretKeys []string) (map[string]string, error)
}

// NewSecretsManager initializes a Secrets Manager.
func NewSecretsManager() *SecretsManager {
	return &SecretsManager{
		secrets: make(map[string]string, 128),
	}
}

// FetchSecrets retrieves secrets for a slice.
func (s *SecretsManager) FetchSecrets(secretKeys []string) (map[string]string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// If cache expired, refresh
	if time.Now().After(s.expiresAt) && s.fetchFunc != nil {
		fetched, err := s.fetchFunc(secretKeys)
		if err != nil {
			return nil, err
		}
		for k, v := range fetched {
			s.secrets[k] = v
		}
		// Refresh TTL: short TTL for JIT fetch
		s.expiresAt = time.Now().Add(5 * time.Minute)
	}

	// Build response
	result := make(map[string]string, len(secretKeys))
	for _, k := range secretKeys {
		if val, ok := s.secrets[k]; ok {
			result[k] = val
		} else {
			result[k] = ""	// placeholder if missing
		}
	}

	return result, nil
}

// InjectFetchFunc wires the backend secrets retrieval function.
func (s *SecretsManager) InjectFetchFunc(fn func(secretKeys []string) (map[string]string, error)) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.fetchFunc = fn
}

// PurgeCache forces cache invalidation.
func (s *SecretsManager) PurgeCache() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.secrets = make(map[string]string, 128)
	s.expiresAt = time.Time{}
}
