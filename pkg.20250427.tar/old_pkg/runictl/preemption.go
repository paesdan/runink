// File: pkg/agent/preemption.go

package agent

import (
	"sync"
	"time"
)

// Preemptor monitors herd resource usage and preempts slices if quotas are exceeded.
// Data-Oriented Design (DOD): flat structs, event batching, minimal allocations.
type Preemptor struct {
	mu          sync.Mutex
	herdUsages  map[string]*HerdUsage
	sliceIndex  map[string]string // sliceID -> herdName
	killFunc    func(sliceID string) error // Injected slice killer
}

// HerdUsage tracks resource usage per herd.
type HerdUsage struct {
	CPUUsed     int64 // milliCPU units (1000 = 1 CPU)
	MemoryUsed  int64 // bytes
	CPULimit    int64 // milliCPU limit
	MemoryLimit int64 // memory limit
	LastUpdate  time.Time
}

// NewPreemptor initializes a preemptor instance.
func NewPreemptor() *Preemptor {
	return &Preemptor{
		herdUsages: make(map[string]*HerdUsage, 64),
		sliceIndex: make(map[string]string, 1024),
	}
}

// RegisterSlice registers a slice under a herd namespace.
func (p *Preemptor) RegisterSlice(sliceID, herdName string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.sliceIndex[sliceID] = herdName
}

// UpdateUsage updates herd CPU and Memory usage periodically.
func (p *Preemptor) UpdateUsage(herdName string, cpuMilli int64, memBytes int64) {
	p.mu.Lock()
	defer p.mu.Unlock()

	hu, exists := p.herdUsages[herdName]
	if !exists {
		hu = &HerdUsage{
			CPULimit:    10000, // default 10 CPU (override via herdloader)
			MemoryLimit: 32 * 1024 * 1024 * 1024, // default 32GiB
		}
		p.herdUsages[herdName] = hu
	}

	hu.CPUUsed = cpuMilli
	hu.MemoryUsed = memBytes
	hu.LastUpdate = time.Now()
}

// CheckAndPreempt scans herds and preempts slices exceeding quotas.
func (p *Preemptor) CheckAndPreempt() {
	p.mu.Lock()
	defer p.mu.Unlock()

	for sliceID, herdName := range p.sliceIndex {
		hu := p.herdUsages[herdName]
		if hu == nil {
			continue
		}
		if hu.CPUUsed > hu.CPULimit || hu.MemoryUsed > hu.MemoryLimit {
			if p.killFunc != nil {
				_ = p.killFunc(sliceID)
				delete(p.sliceIndex, sliceID)
				// TODO: Log preemption event for audit trail
			}
		}
	}
}

// InjectKillFunc injects the slice kill function.
func (p *Preemptor) InjectKillFunc(kf func(sliceID string) error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.killFunc = kf
}
