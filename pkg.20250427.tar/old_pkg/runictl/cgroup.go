// File: pkg/slice/cgroup.go

package slice

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
)

// CgroupConfig defines CPU and memory limits for a slice.
// Data-Oriented Design (DOD): flat struct, direct field access.
type CgroupConfig struct {
	SliceName    string
	CPUQuotaUSec int64  // Microseconds per 100ms period (100000 = 100%)
	MemoryBytes  int64  // Max memory in bytes
}

const (
	cgroupBasePath = "/sys/fs/cgroup"
)

// SetupCgroup configures a cgroup v2 for the slice.
func SetupCgroup(cfg CgroupConfig) error {
	path := filepath.Join(cgroupBasePath, cfg.SliceName)

	if err := os.MkdirAll(path, 0755); err != nil {
		return fmt.Errorf("failed to create cgroup path: %w", err)
	}

	// Set CPU quota
	cpuMaxPath := filepath.Join(path, "cpu.max")
	cpuContent := fmt.Sprintf("%d 100000", cfg.CPUQuotaUSec) // 100ms period
	if err := os.WriteFile(cpuMaxPath, []byte(cpuContent), 0644); err != nil {
		return fmt.Errorf("failed to set cpu.max: %w", err)
	}

	// Set memory limit
	memMaxPath := filepath.Join(path, "memory.max")
	memContent := strconv.FormatInt(cfg.MemoryBytes, 10)
	if err := os.WriteFile(memMaxPath, []byte(memContent), 0644); err != nil {
		return fmt.Errorf("failed to set memory.max: %w", err)
	}

	return nil
}

// AttachPID attaches a running PID to the slice cgroup.
func AttachPID(sliceName string, pid int) error {
	path := filepath.Join(cgroupBasePath, sliceName, "cgroup.procs")
	content := strconv.Itoa(pid)
	if err := os.WriteFile(path, []byte(content), 0644); err != nil {
		return fmt.Errorf("failed to attach pid to cgroup: %w", err)
	}
	return nil
}

// CleanupCgroup removes a slice cgroup.
func CleanupCgroup(sliceName string) error {
	path := filepath.Join(cgroupBasePath, sliceName)
	return os.RemoveAll(path)
}
