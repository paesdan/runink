package envloader

import (
	"fmt"
	"os"
	"strconv"
)

// LoadFromFile reads key=value pairs into env variables
func LoadFromFile(path string) error {
	pairs, err := ParseEnvFile(path)
	if err != nil {
		return fmt.Errorf("failed to parse env file: %w", err)
	}

	for key, value := range pairs {
		if err := os.Setenv(key, value); err != nil {
			return fmt.Errorf("failed to set env var %s: %w", key, err)
		}
	}
	return nil
}

// LoadComplianceFromEnv populates Compliance metadata from env vars
func LoadComplianceFromEnv() OperationalCompliance {
	return OperationalCompliance{
		OperationalStatus:   os.Getenv(EnvComplianceOperationalStatus),
		RecoveryStatus:      os.Getenv(EnvComplianceRecoveryStatus),
		DataSecurityStatus:  os.Getenv(EnvComplianceDataSecurityStatus),
		AccessControlStatus: os.Getenv(EnvComplianceAccessControlStatus),
	}
}

// LoadMetadataFromEnv populates a DSL Metadata struct from env vars
func LoadMetadataFromEnv() Metadata {
	tlsRequired := false
	tlsEnv := os.Getenv(EnvTLSRequired)
	if tlsEnv == "true" || tlsEnv == "1" {
		tlsRequired = true
	}

	return Metadata{
		Feature:          os.Getenv(EnvFeature),
		Scenario:         os.Getenv(EnvScenario),
		Herd:             os.Getenv(EnvHerd),
		Contract:         os.Getenv(EnvContract),
		Version:          os.Getenv(EnvContractVersion),
		ContractHash:     os.Getenv(EnvContractHash),
		LineageID:        os.Getenv(EnvLineageID),
		QualityTier:      os.Getenv(EnvQualityTier),
		SLO:              os.Getenv(EnvSLO),
		Classification:   os.Getenv(EnvClassification),
		GovernancePolicy: os.Getenv(EnvGovernancePolicy),
		AccessPolicy:     os.Getenv(EnvAccessPolicy),
		TLSRequired:      tlsRequired,
		Compliance:       LoadComplianceFromEnv(),
	}
}
