// File: pkg/slice/execution.go

package slice

import (
	"errors"
	"io"
	"os"
	"sync"
)

// Stage defines a transform step in a pipeline.
type Stage struct {
	Name      string
	Transform func(io.Reader, io.Writer) error
}

// ExecutionPipeline manages streaming stage execution.
// Data-Oriented Design: flat structs, minimal heap allocation.
type ExecutionPipeline struct {
	stages []Stage
	pool   sync.Pool
}

// NewExecutionPipeline initializes an execution pipeline.
func NewExecutionPipeline(stages []Stage) *ExecutionPipeline {
	return &ExecutionPipeline{
		stages: stages,
		pool: sync.Pool{
			New: func() interface{} {
				return make([]byte, 64*1024) // Preallocate 64KB buffers
			},
		},
	}
}

// Run executes all stages connected by io.Pipes.
func (ep *ExecutionPipeline) Run(src io.Reader, sink io.Writer) error {
	if len(ep.stages) == 0 {
		return errors.New("no stages defined")
	}

	var readers []io.Reader
	var writers []io.Writer

	// Build pipe chain
	for range ep.stages[:len(ep.stages)-1] {
		r, w := io.Pipe()
		readers = append(readers, r)
		writers = append(writers, w)
	}

	// Source to first stage input
	firstReader := src
	firstWriter := writers[0]

	// Last stage output to final sink
	lastReader := readers[len(readers)-1]
	lastWriter := sink

	// Launch goroutines for stages
	for i, stage := range ep.stages {
		var in io.Reader
		var out io.Writer

		if i == 0 {
			in = firstReader
			out = firstWriter
		} else if i == len(ep.stages)-1 {
			in = readers[i-1]
			out = lastWriter
		} else {
			in = readers[i-1]
			out = writers[i]
		}

		go ep.runStage(stage, in, out)
	}

	return nil
}

// runStage runs a single transform stage.
func (ep *ExecutionPipeline) runStage(stage Stage, r io.Reader, w io.Writer) {
	defer func() {
		if c, ok := w.(io.Closer); ok {
			_ = c.Close()
		}
	}()
	_ = stage.Transform(r, w)
}

// Example: simple passthrough transform
func IdentityTransform(r io.Reader, w io.Writer) error {
	buf := make([]byte, 4096)
	for {
		n, err := r.Read(buf)
		if n > 0 {
			_, _ = w.Write(buf[:n])
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
	}
	return nil
}
