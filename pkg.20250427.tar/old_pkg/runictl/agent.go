// File: pkg/agent/agent.go

package agent

import (
	"context"
	"time"

	"github.com/runink/pkg/envloader"
	"github.com/runink/pkg/herdloader"
)

// Agent defines the core Runi Agent structure
// Data-Oriented Design: Prefer flat structs for cache efficiency.
type Agent struct {
	NodeID       string
	HerdConfig   herdloader.HerdConfig
	EnvConfig    envloader.EnvConfig
	HeartbeatCh  chan Heartbeat
	CommandCh    chan AgentCommand
	SliceRunner  *Runner
	Preemptor    *Preemptor
	SecretsMgr   *SecretsManager
	Metrics      *MetricsMonitor
}

// AgentCommand models a command fetched from the Control Plane.
type AgentCommand struct {
	CommandType string
	Payload     []byte // Payload is unmarshalled in slice runner or preemptor
}

// Heartbeat defines health information sent to Control Plane.
type Heartbeat struct {
	Timestamp time.Time
	CPUUsage  float64
	MemUsage  float64
	SliceCount int
}

// NewAgent initializes a new agent instance.
func NewAgent(nodeID string, herd herdloader.HerdConfig, env envloader.EnvConfig) *Agent {
	return &Agent{
		NodeID:      nodeID,
		HerdConfig:  herd,
		EnvConfig:   env,
		HeartbeatCh: make(chan Heartbeat, 10),
		CommandCh:   make(chan AgentCommand, 50),
		SliceRunner: NewRunner(),
		Preemptor:   NewPreemptor(),
		SecretsMgr:  NewSecretsManager(),
		Metrics:     NewMetricsMonitor(),
	}
}

// Start launches the Agent lifecycle.
func (a *Agent) Start(ctx context.Context) error {
	// Zero-copy design: Channels pass references, no duplication.
	go a.heartbeatLoop(ctx)
	go a.commandLoop(ctx)
	return nil
}

// heartbeatLoop periodically sends node heartbeats.
func (a *Agent) heartbeatLoop(ctx context.Context) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			a.HeartbeatCh <- a.collectHeartbeat()
		}
	}
}

// collectHeartbeat gathers CPU, memory, and slice metrics.
func (a *Agent) collectHeartbeat() Heartbeat {
	return Heartbeat{
		Timestamp: time.Now(),
		CPUUsage:  a.Metrics.CollectCPUUsage(),
		MemUsage:  a.Metrics.CollectMemoryUsage(),
		SliceCount: a.Metrics.RunningSlices(),
	}
}

// commandLoop processes commands from the Control Plane.
func (a *Agent) commandLoop(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		case cmd := <-a.CommandCh:
			a.dispatch(cmd)
		}
	}
}

// dispatch routes commands to SliceRunner or Preemptor.
func (a *Agent) dispatch(cmd AgentCommand) {
	switch cmd.CommandType {
	case "launch_slice":
		a.SliceRunner.Launch(cmd.Payload)
	case "preempt_slice":
		a.Preemptor.Kill(cmd.Payload)
	default:
		// Future extensibility
	}
}
