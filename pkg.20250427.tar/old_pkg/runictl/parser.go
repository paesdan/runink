package envloader

import (
	"bufio"
	"os"
	"strings"
)

// ParseEnvFile loads key=value lines into a map
func ParseEnvFile(path string) (map[string]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	envs := make(map[string]string, 128) // Preallocated for typical size

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := cleanLine(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		envs[key] = val
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return envs, nil
}
