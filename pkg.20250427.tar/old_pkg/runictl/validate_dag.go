// File: pkg/agent/validate.go

package agent

import (
	"encoding/json"
	"errors"
	"io"
)

// DAGValidator provides DAG validation helpers.
// Data-Oriented Design (DOD): flat structs, efficient validation loops.
type DAGValidator struct{}

// ValidationError represents a failed validation.
type ValidationError struct {
	Field   string
	Message string
}

// ValidateContract checks that contract metadata fields are valid.
func (v *DAGValidator) ValidateContract(r io.Reader) ([]ValidationError, error) {
	dec := json.NewDecoder(r)
	var contract map[string]interface{} // Streaming: no full deserialization

	err := dec.Decode(&contract)
	if err != nil {
		return nil, err
	}

	var errs []ValidationError
	// Example: Required fields check
	required := []string{"contract_id", "fields", "version"}
	for _, key := range required {
		if _, ok := contract[key]; !ok {
			errs = append(errs, ValidationError{
				Field:   key,
				Message: "missing required field",
			})
		}
	}

	return errs, nil
}

// ValidateScenario checks the scenario for structural errors.
func (v *DAGValidator) ValidateScenario(r io.Reader) ([]ValidationError, error) {
	dec := json.NewDecoder(r)
	var scenario map[string]interface{}

	err := dec.Decode(&scenario)
	if err != nil {
		return nil, err
	}

	var errs []ValidationError
	// Example: Must have at least one step
	if steps, ok := scenario["steps"].([]interface{}); !ok || len(steps) == 0 {
		errs = append(errs, ValidationError{
			Field:   "steps",
			Message: "must define at least one step",
		})
	}

	return errs, nil
}

// MergeErrors merges multiple validation error slices into one.
func MergeErrors(all ...[]ValidationError) []ValidationError {
	size := 0
	for _, errs := range all {
		size += len(errs)
	}

	out := make([]ValidationError, 0, size)
	for _, errs := range all {
		out = append(out, errs...)
	}
	return out
}

// ValidateDAG validates both Contract and Scenario streams together.
func (v *DAGValidator) ValidateDAG(contractR, scenarioR io.Reader) ([]ValidationError, error) {
	cErrs, err := v.ValidateContract(contractR)
	if err != nil {
		return nil, errors.New("invalid contract format")
	}

	sErrs, err := v.ValidateScenario(scenarioR)
	if err != nil {
		return nil, errors.New("invalid scenario format")
	}

	return MergeErrors(cErrs, sErrs), nil
}

package envloader

import (
	"fmt"
	"os"
)

// ValidateRequiredKeys checks if env vars are present
func ValidateRequiredKeys(keys []string) error {
	for _, key := range keys {
		if os.Getenv(key) == "" {
			return fmt.Errorf("required env var missing: %s", key)
		}
	}
	return nil
}

func ValidateComplianceEnv() error {
	return ValidateRequiredKeys([]string{
		EnvComplianceOperationalStatus,
		EnvComplianceRecoveryStatus,
		EnvComplianceDataSecurityStatus,
		EnvComplianceAccessControlStatus,
	})
}

func ValidateMetadataEnv() error {
	return ValidateRequiredKeys([]string{
		EnvFeature,
		EnvScenario,
		EnvHerd,
		EnvContract,
		EnvContractVersion,
	})
}
