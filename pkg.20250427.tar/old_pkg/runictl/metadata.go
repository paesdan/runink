package envloader

// Metadata holds environment-driven metadata used across Runink
type Metadata struct {
	Feature          string                `json:"feature" yaml:"feature"`
	Scenario         string                `json:"scenario" yaml:"scenario"`
	Herd             string                `json:"herd" yaml:"herd"`
	Contract         string                `json:"contract" yaml:"contract"`
	Version          string                `json:"version" yaml:"version"`
	ContractHash     string                `json:"contract_hash" yaml:"contract_hash"`
	LineageID        string                `json:"lineage_id" yaml:"lineage_id"`
	QualityTier      string                `json:"quality_tier" yaml:"quality_tier"`
	SLO              string                `json:"slo" yaml:"slo"`
	Classification   string                `json:"classification" yaml:"classification"`
	GovernancePolicy string                `json:"governance_policy" yaml:"governance_policy"`
	AccessPolicy     string                `json:"access_policy" yaml:"access_policy"`
	TLSRequired      bool                  `json:"tls_required" yaml:"tls_required"`
	Compliance       OperationalCompliance `json:"compliance" yaml:"compliance"`
}

// OperationalCompliance represents compliance indicators enforced via env
type OperationalCompliance struct {
	OperationalStatus   string `json:"operational_status" yaml:"operational_status"`
	RecoveryStatus      string `json:"recovery_status" yaml:"recovery_status"`
	DataSecurityStatus  string `json:"data_security_status" yaml:"data_security_status"`
	AccessControlStatus string `json:"access_control_status" yaml:"access_control_status"`
}
