package envloader

import "strings"

func cleanLine(s string) string {
	return strings.TrimSpace(s)
}

// File: pkg/slice/utils.go

package slice

import (
	"fmt"
	"time"
)

// RetryConfig defines the settings for retrying operations.
type RetryConfig struct {
	MaxAttempts int
	Backoff     time.Duration
	Timeout     time.Duration
}

// Retry executes fn with retry and backoff strategy.
func Retry(cfg RetryConfig, fn func() error) error {
	var lastErr error
	for i := 0; i < cfg.MaxAttempts; i++ {
		if err := fn(); err != nil {
			lastErr = err
			time.Sleep(cfg.Backoff)
			continue
		}
		return nil
	}
	return fmt.Errorf("retry: failed after %d attempts, last error: %w", cfg.MaxAttempts, lastErr)
}

// RetryWithTimeout retries fn until it succeeds or timeout is reached.
func RetryWithTimeout(cfg RetryConfig, fn func() error) error {
	timer := time.NewTimer(cfg.Timeout)
	defer timer.Stop()
	ticker := time.NewTicker(cfg.Backoff)
	defer ticker.Stop()

	for {
		select {
		case <-timer.C:
			return fmt.Errorf("retry: timeout after %s", cfg.Timeout)
		case <-ticker.C:
			if err := fn(); err == nil {
				return nil
			}
		}
	}
}

// AggregateErrors aggregates multiple errors into one.
type AggregateErrors struct {
	Errors []error
}

func (a *AggregateErrors) Error() string {
	msg := "multiple errors:"
	for _, err := range a.Errors {
		msg += "\n - " + err.Error()
	}
	return msg
}

// AppendError appends a new error to the aggregator.
func (a *AggregateErrors) AppendError(err error) {
	if err != nil {
		a.Errors = append(a.Errors, err)
	}
}

// HasErrors checks if any errors were recorded.
func (a *AggregateErrors) HasErrors() bool {
	return len(a.Errors) > 0
}
