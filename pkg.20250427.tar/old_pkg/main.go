package main

import (
    "github.com/runink/runink/cmd/runi"
)

func main() {
    runi.Execute()
}
