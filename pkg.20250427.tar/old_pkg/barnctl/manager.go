package secrets

type SecretManager interface { // <-- Renamed from Manager
	PutSecret(req PutRequest) error
	GetSecret(req GetRequest) (Secret, error)
	DeleteSecret(req DeleteRequest) error
	ListSecrets(req ListRequest) ([]Secret, error)
}

// Request/Response Models

type PutRequest struct {
	Herd     string
	Feature  string
	Scenario string
	Key      string
	Value    []byte
	TTL      int64 // optional expiry seconds
}

type GetRequest struct {
	Herd     string
	Feature  string
	Scenario string
	Key      string
	Version  string // optional version: V1, V2, etc
}

type DeleteRequest struct {
	Herd     string
	Feature  string
	Scenario string
	Key      string
	Version  string // optional
}

type ListRequest struct {
	Herd     string
	Feature  string
	Scenario string
}

type Secret struct {
	Key        string
	Value      []byte
	CreatedAt  int64
	ExpiresAt  int64
	VersionID  string
	CreatedBy  string
}

// Implementation of Manager

type Manager struct{}

func (m *Manager) PutSecret(req PutRequest) error {
	err := PutSecret(req)
	if err == nil {
		AuditLog("PUT", req.Herd, req.Feature, req.Scenario, req.Key, "")
	}
	return err
}

func (m *Manager) GetSecret(req GetRequest) (Secret, error) {
	secret, err := GetSecret(req)
	if err == nil {
		AuditLog("GET", req.Herd, req.Feature, req.Scenario, req.Key, req.Version)
	}
	return secret, err
}

func (m *Manager) DeleteSecret(req DeleteRequest) error {
	err := DeleteSecret(req)
	if err == nil {
		AuditLog("DELETE", req.Herd, req.Feature, req.Scenario, req.Key, req.Version)
	}
	return err
}

func (m *Manager) ListSecrets(req ListRequest) ([]Secret, error) {
	secrets, err := ListSecrets(req)
	if err == nil {
		AuditLog("LIST", req.Herd, req.Feature, req.Scenario, "", "")
	}
	return secrets, err
}
