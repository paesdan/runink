package raftctl

import (
	"fmt"
	"github.com/runink/pkg/badgerstore"
	"github.com/runink/pkg/dsl"
	"github.com/runink/pkg/herdloader"
)

type Client struct{}

func NewClient() *Client {
	if err := badgerstore.Open("/var/runink/raftdb"); err != nil {
		panic(fmt.Sprintf("❌ Failed to open Badger store: %v", err))
	}
	return &Client{}
}

func (c *Client) Close() {
	_ = badgerstore.Close()
}

func (c *Client) RegisterFeatureFullMetadata(meta dsl.Metadata, herd herdloader.HerdConfig) error {
	if err := ValidateMetadata(meta, herd); err != nil {
		return err
	}
	key := badgerstore.KeyForFeature(meta.Herd, meta.Feature)
	payload, err := badgerstore.Marshal(meta)
	if err != nil {
		return err
	}
	return badgerstore.Put(key, payload, 0)
}

func (c *Client) RegisterHerdMetadata(herd herdloader.HerdConfig) error {
	key := "herd/" + herd.Name
	payload, err := badgerstore.Marshal(herd)
	if err != nil {
		return err
	}
	return badgerstore.Put(key, payload, 0)
}

func (c *Client) SnapshotState(outputPath string) error {
	return badgerstore.BackupToFile(outputPath)
}
