package raftctl

import (
	"io"
	"github.com/dgraph-io/badger/v3"
	"github.com/runink/pkg/badgerstore"
)

// BackupSnapshot streams the raft metadata DB
func (c *Client) BackupSnapshot(w io.Writer) error {
	return badgerstore.BackupDB(w)
}

// RestoreSnapshot restores the raft metadata DB
func (c *Client) RestoreSnapshot(r io.Reader) error {
	return badgerstore.RestoreDB(r)
}

// BackupDB creates a full DB snapshot
func BackupDB(w io.Writer) error {
	return db.Backup(w, 0)
}

// RestoreDB restores a full DB snapshot
func RestoreDB(r io.Reader) error {
	return db.Load(r, 10)
}
