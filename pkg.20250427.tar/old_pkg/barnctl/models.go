package secrets

type Secret struct {
	Herd      string
	Feature   string
	Scenario  string
	Key       string
	Versions  []SecretVersion
	CreatedAt int64
}

type SecretVersion struct {
	VersionID      string
	EncryptedValue []byte
	CreatedAt      int64
	ExpiresAt      int64
	CreatedBy      string
}

type PutRequest struct {
	Herd     string
	Feature  string
	Scenario string
	Key      string
	Value    []byte
	TTL      int64 // seconds
}

type GetRequest struct {
	Herd     string
	Feature  string
	Scenario string
	Key      string
	Version  string // optional: V1, V2
}

type DeleteRequest struct {
	Herd     string
	Feature  string
	Scenario string
	Key      string
	Version  string // optional: delete specific version
}

type ListRequest struct {
	Herd     string
	Feature  string
	Scenario string
}
