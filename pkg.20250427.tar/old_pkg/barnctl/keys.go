package badgerstore

// KeyForFeature returns the key for feature metadata
func KeyForFeature(herd, feature string) string {
	return "herd/" + herd + "/feature/" + feature
}

// KeyForScenario returns the key for a specific scenario
func KeyForScenario(herd, feature, scenario string) string {
	return "herd/" + herd + "/feature/" + feature + "/scenario/" + scenario
}

// KeyForSecret returns the key for a versioned secret
func KeyForSecret(herd, feature, scenario, key string, version int) string {
	return "herd/" + herd + "/feature/" + feature + "/scenario/" + scenario + "/secret/" + key + "/v" + string(rune(version))
}
