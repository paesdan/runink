package raftctl

import (
	"fmt"
	"time"
)

// Assume raft global or passed dependency
var raftStore map[string]FeatureRegistration = make(map[string]FeatureRegistration)

// NewClient returns a new default client
func NewClient() Client {
	return &defaultClient{}
}

type defaultClient struct{}

func (c *defaultClient) RegisterFeatureFullMetadata(meta envloader.Metadata, herd herdloader.HerdConfig) error {
	if meta.Feature == "" || meta.Scenario == "" {
		return fmt.Errorf("feature and scenario are required")
	}

	reg := FeatureRegistration{
		HerdConfig:      herd,
		FeatureMetadata: meta,
		Timestamp:       time.Now().Unix(),
	}

	key := fmt.Sprintf("%s:%s", meta.Herd, meta.Feature)
	raftStore[key] = reg
	return nil
}

func (c *defaultClient) GetFeatureMetadata(feature string) (FeatureRegistration, error) {
	for _, reg := range raftStore {
		if reg.FeatureMetadata.Feature == feature {
			return reg, nil
		}
	}
	return FeatureRegistration{}, fmt.Errorf("feature not found")
}

func (c *defaultClient) ListAllFeatures() ([]FeatureRegistration, error) {
	var regs []FeatureRegistration
	for _, reg := range raftStore {
		regs = append(regs, reg)
	}
	return regs, nil
}

// RegisterGeneratorMetadata persists generator metadata into Raft+Badger
func (c *Client) RegisterGeneratorMetadata(meta generator.GeneratorMetadata) error {
	key := badgerstore.KeyForGeneratorMetadata(meta.HerdConfig.Name, meta.FeatureMetadata.Feature)

	payload, err := badgerstore.Marshal(meta)
	if err != nil {
		return err
	}

	return badgerstore.Put(key, payload, 0)
}

func (c *defaultClient) SnapshotState() error {
	// TODO: Serialize raftStore to disk (BadgerDB or flat file)
	return nil
}
