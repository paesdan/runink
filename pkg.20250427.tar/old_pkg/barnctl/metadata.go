package secrets

import {
	"github.com/runink/pkg/envloader"
	"github.com/runink/pkg/herdloader"

}
// Secret represents a versioned and encrypted secret
type Secret struct {
	Key         string              `json:"key"`
	Value       []byte               `json:"value"`
	Version     int                  `json:"version"`
	CreatedAt   int64                `json:"created_at"`
	ExpiresAt   int64                `json:"expires_at"`
	Metadata    envloader.Metadata   `json:"metadata"` // 🛡 Full feature lineage metadata (Feature, Scenario, Herd, SLA, etc)
	Checksum    string               `json:"checksum"` // Integrity check (SHA256 hash of Value)
	Encryption  string               `json:"encryption"` // E.g., AES256-GCM
	RotationDue int64                `json:"rotation_due"` // When the secret must be rotated (timestamp)
	Status      string               `json:"status"` // Active / Expired / Archived
}

// PutRequest is the payload to store a secret
type PutRequest struct {
	Herd        string `json:"herd"`
	Feature     string `json:"feature"`
	Scenario    string `json:"scenario"`
	Key         string `json:"key"`
	Value       []byte `json:"value"`
	TTL         int64  `json:"ttl,omitempty"` // Optional expiry in seconds
	Encrypted   bool   `json:"encrypted"` // Should always be true in Runink
}

// GetRequest retrieves a secret (optionally specific version)
type GetRequest struct {
	Herd        string `json:"herd"`
	Feature     string `json:"feature"`
	Scenario    string `json:"scenario"`
	Key         string `json:"key"`
	Version     int    `json:"version,omitempty"` // If 0, get latest
}

// DeleteRequest deletes a secret key or specific version
type DeleteRequest struct {
	Herd        string `json:"herd"`
	Feature     string `json:"feature"`
	Scenario    string `json:"scenario"`
	Key         string `json:"key"`
	Version     int    `json:"version,omitempty"` // Optional, otherwise all versions
}

// ListRequest lists secrets by herd/feature/scenario context
type ListRequest struct {
	Herd        string `json:"herd"`
	Feature     string `json:"feature"`
	Scenario    string `json:"scenario"`
}

// Full metadata payload registered into Raft
type FeatureRegistration struct {
	HerdConfig     herdloader.HerdConfig
	FeatureMetadata envloader.Metadata
	Timestamp       int64 // Epoch timestamp of registration
}
