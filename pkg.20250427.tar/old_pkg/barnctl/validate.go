package raftctl

import "errors"

func ValidateRegistration(r FeatureRegistration) error {
	if r.FeatureMetadata.Feature == "" {
		return errors.New("missing feature name")
	}
	if r.HerdConfig.Name == "" {
		return errors.New("missing herd name")
	}
	return nil
}
