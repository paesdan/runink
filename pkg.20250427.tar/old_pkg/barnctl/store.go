package secrets

import (
	"github.com/dgraph-io/badger/v3"
	"time"
	"log"
)

var db *badger.DB

func InitStore(path string) error {
	opts := badger.DefaultOptions(path).WithLogger(nil)
	var err error
	db, err = badger.Open(opts)
	return err
}

func PutSecret(req PutRequest, createdBy string) error {
	err := CheckHerdBoundary(req.Herd, req.Feature, req.Scenario)
	if err != nil {
		return err
	}

	encVal, err := Encrypt(req.Value)
	if err != nil {
		return err
	}

	versionID := generateVersionID()
	key := storageKey(req.Herd, req.Feature, req.Scenario, req.Key, versionID)

	return db.Update(func(txn *badger.Txn) error {
		return txn.Set([]byte(key), encVal)
	})
}

func GetSecret(req GetRequest) ([]byte, error) {
	err := CheckHerdBoundary(req.Herd, req.Feature, req.Scenario)
	if err != nil {
		return nil, err
	}

	version := req.Version
	if version == "" {
		version = "latest" // TODO resolve latest properly
	}
	key := storageKey(req.Herd, req.Feature, req.Scenario, req.Key, version)

	var valCopy []byte
	err = db.View(func(txn *badger.Txn) error {
		item, err := txn.Get([]byte(key))
		if err != nil {
			return err
		}
		val, err := item.ValueCopy(nil)
		if err != nil {
			return err
		}
		valCopy = val
		return nil
	})
	if err != nil {
		return nil, err
	}
	return Decrypt(valCopy)
}

func storageKey(herd, feature, scenario, key, version string) string {
	return "secrets/" + herd + "/" + feature + "/" + scenario + "/" + key + "/" + version
}

func generateVersionID() string {
	return "V" + time.Now().Format("20060102150405")
}



var db *badger.DB

// Open initializes the BadgerDB instance
func Open(path string) error {
	opts := badger.DefaultOptions(path).
		WithLogger(nil).         // Disable noisy logs
		WithSyncWrites(true).     // Stronger durability
		WithTruncate(true)        // Faster crash recovery
	dbInternal, err := badger.Open(opts)
	if err != nil {
		return err
	}
	db = dbInternal
	return nil
}

// Close gracefully closes the DB
func Close() error {
	return db.Close()
}

// Put stores a key-value with optional TTL
func Put(key string, value []byte, ttlSeconds int64) error {
	return db.Update(func(txn *badger.Txn) error {
		e := badger.NewEntry([]byte(key), value)
		if ttlSeconds > 0 {
			e = e.WithTTL(time.Duration(ttlSeconds) * time.Second)
		}
		return txn.SetEntry(e)
	})
}

// Get retrieves value by key
func Get(key string) ([]byte, error) {
	var valCopy []byte
	err := db.View(func(txn *badger.Txn) error {
		item, err := txn.Get([]byte(key))
		if err != nil {
			return err
		}
		return item.Value(func(val []byte) error {
			valCopy = append([]byte{}, val...)
			return nil
		})
	})
	return valCopy, err
}

// Delete removes a key
func Delete(key string) error {
	return db.Update(func(txn *badger.Txn) error {
		return txn.Delete([]byte(key))
	})
}

// ListPrefix lists all keys starting with prefix
func ListPrefix(prefix string) ([]string, error) {
	var keys []string
	err := db.View(func(txn *badger.Txn) error {
		it := txn.NewIterator(badger.DefaultIteratorOptions)
		defer it.Close()
		for it.Seek([]byte(prefix)); it.ValidForPrefix([]byte(prefix)); it.Next() {
			keys = append(keys, string(it.Item().Key()))
		}
		return nil
	})
	return keys, err
}
