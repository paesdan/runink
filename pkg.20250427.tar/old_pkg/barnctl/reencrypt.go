package secrets

// RotateMasterKey re-encrypts all secrets with a new master key
func RotateMasterKey(newKey []byte) error {
	// TODO: walk through all secrets, decrypt with old key, encrypt with new key
	return nil
}
