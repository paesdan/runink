package raftctl

import "strings"

func SanitizeKey(herd, feature string) string {
	return herd + ":" + feature
}

func sanitizeKey(s string) string {
	return strings.ReplaceAll(s, " ", "_")
}

// Marshal wraps JSON encoding
func Marshal(v interface{}) ([]byte, error) {
	return json.Marshal(v)
}

// Unmarshal wraps JSON decoding
func Unmarshal(data []byte, v interface{}) error {
	return json.Unmarshal(data, v)
}

// KeyForGeneratorMetadata returns the key for a generated DAG metadata
func KeyForGeneratorMetadata(herd, feature string) string {
	return fmt.Sprintf("generator/%s/%s", sanitizeKey(herd), sanitizeKey(feature))
}
