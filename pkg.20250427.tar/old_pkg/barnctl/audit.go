package secrets

import "log"

func AuditLog(action, herd, feature, scenario, key, version string) {
	log.Printf("[AUDIT] %s secret %s (version %s) in herd=%s feature=%s scenario=%s", 
		action, key, version, herd, feature, scenario)
}
