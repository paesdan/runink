package badgerstore

import (
	"github.com/dgraph-io/badger/v3"
)

// DefaultOptions returns the options for Badger durable mode
func DefaultOptions(path string) badger.Options {
	return badger.DefaultOptions(path).
		WithSyncWrites(true).
		WithValueDir(path).
		WithLogger(nil)
}
