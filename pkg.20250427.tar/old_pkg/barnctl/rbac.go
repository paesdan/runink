package secrets

import "errors"

// Mock authz until integrated properly
func CheckHerdBoundary(herd, feature, scenario string) error {
	// later load herd-scoped RBAC policies here
	return nil
}
